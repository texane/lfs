
/*+*****************************************************************************

 File       : PCYCLE.C      
 Project    : Test program for basic PCI operations.
 Description: Uses the generic driver PCIDRVGEN (M. Perez/Ph. Chappelet)
 Author(s)  : Ph. Chappelet

 Rev 1.0    : 01/01/2002 - Creation 
 Rev 1.1    : 01/02/2002 - Beta release #1 
 Rev 1.2    : 01/03/2002 - Beta release #2
 Rev 1.3    : 01/05/2002 - Mise en place Ecriture/Lecture en Burst.
 Rev 1.4    : 23/10/2002 - Update fct TEST_OPEN() suite a la modif de librairie
			 - Correction bug sur l'execution de la meme commande
			   par un simple retour chariot dans le menu.
                         - Recompilation avec librairie libtstpci_V11.a
 Rev 1.5    : 27/02/2007 - Recompilation avec librairie libtstpci_V14.a
                           (pour ESRF/Linux & Kernel 2.6)

 Copyright (c) 2002 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

#include <sys/stat.h>

#include "pcycle.h"

static char *version_msg = 
"*------------------ PCYCLE : Revision 1.5 (27/02/2007) -----------------*";

/*
 User's instructions
 */

static char *usage_msg =
"\nUsage: pcycle [-D <Device ID>] [-# <badr(0,..,5)>] [-h] [-d <lvl(0,..,4)>]\n\
    -D    specify a Device ID to access\n\
    -#    set PCI base address reg. to work with\n\
    -h    display this help and exit.\n\
    -d    set debug level of driver PCIDRVGEN to display less or more infos.\n\
"; 

struct option longopts[] = {
    {"DID",   required_argument, NULL, 'D'},  /* Define debug level */
	{"badr",  required_argument, NULL, '#'},  /* Select a Base Adrs reg. */
	{"help",        no_argument, NULL, 'h'},  /* Display Help message */
	{"debug", required_argument, NULL, 'd'},  /* Define debug level */
	{ 0, 0, 0, 0 } /* last element of the array */	
};

static char help_pcycle[] = "\n\
The program 'PCYCLE' aims to perform basic PCI operations.\n\n\
This program deals with the generic character device driver `PCIDRVGEN'.\n\
This driver only features Open(), Close() & IOCtl() functions.\n\
Don't forget to execute the script `PCIDRVGEN_load' before running `PCYCLE' :\n\
WARNING : that script must be launched when logged as Root.\n\
By running the shell command : tail -f /var/log/messages (as root),\n\
it is possible to trace on screen the driver activity.\n\n\
When running, the menu proposes the command \"# badr\" allowing the user to\n\
select one I/O or Memory space (out of 6) dynamically mapped by the system.\n\
The prompt message displays the 3 following fields : \n\
      #badr   : I/O & Memory Base Adrs Reg. [0..5] (default = 1)\n\
      ($adrs) : the physical address pointed by <badr>.\n\
      +n      : address increment in hexa (when using do(v) command).\n\
REM : when doing a Read or Write command, the <offs> parameter is the\n\
      offset related to the Base Adrs Register being selected.\n\
";

char dma_file[80];
unsigned int Bcnt;

int PCI_Cycle(u_int code, u_int badr, u_int offs, u_int data, u_int count);
int Ask_Param(char *);

/**/
void Display_Menu(void)
/*+*****************************************************************************
 Purpose     : display the menu of test program.
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	Set_Bold();
	printf("\n%s", version_msg);
	Clr_Attr();
	printf(" %s\n\n", msg_dbg[opt_dbg]);

	printf("#         badr             : set Base Addr reg. to <badr> in range [0,..,5]\n");
	printf("+         inc              : set address increment to <inc> (in (h)exa)\n");
	printf("!         cmd              : escape to the shell for executing <cmd>\n");
	printf("r[b/w/l]  offs             : Single read  (8/16/32 bits) from <offs(h)>\n");
	printf("w[b/w/l]  offs data        : Single write (8/16/32 bits) <data(h)> to <offs(h)>\n");
	printf("br[b/w/l] offs cnt         : Burst read from <offs(h)> for <cnt(d)> cycles\n");
	printf("bw[b/w/l] offs [d/f] (cnt) : Burst write <d>ata value or <f>ile contents\n");
	printf("do(v)     n                : redo last cmd <n(d)> times\n");
	printf("                             (n=0 -> endless loop / (v) -> verbose)\n");
	printf("rh(s/l)                    : read Config. Header in (s)hort or (l)ong format\n");

	if (chip_AMCC) {
		printf("[r/w/c]nv                  : (r)ead, (w)rite or (c)ompare AMCC NVram\n");
		/* printf("bm[r/w]                    : bus master (r)ead or (w)rite transfert\n"); */
		printf("ldx       file             : load CUB virtex with BIT <file> thru AMCC\n");
		}
	
	printf("q                          : quit\n");
}







/**/
int main(int argc, char **argv)
/*+*****************************************************************************
 Purpose    : Main section of User's program
 Description:
 Argv[1]    :
 Arg(s) Out : None
 Return(s)  :
*****************************************************************************-*/
{
	char KbdIn[80],        /* characters buffer for keyboard input */
		 Line[80],         /* command line to execute */
	     CodeOp[8];        /* command to execute (1rst field input) */
	
	u_int did = 0xFFFF;
	
	int i, j, c, error, longind;

	int Loop,              /* number of times to perform the same cmd */
	    Code,              /* represents the HARD command typed in by user */
	    Match,             /* return value of sscanf() fct = number of param. */
	    Arg,               /* store the 2nd field of keyboard input */
	    Display_Cmd;       /* display mode = Verbose or Mute for do(v) cmd */

	int CmdType;           /* type of command to execute : */
			       /* -1 : UNDEFINED   -> command not yet defined */
			       /*  1 : ACCESS_HARD -> to do hardware access */
		               /*  2 : CONFIG_SOFT -> to set soft config (.;+) */
			       /*  0 : EXIT        -> to leave the program */
			      	
	unsigned int Badr = 1, /* PCI base address reg [0,..,5] */
	             Offs = 0, /* address Offset where to perform access */
	             Step;     /* address increment */

	char bit_file[80];     /* BIT file name to download into the CUB's Virtex */   
/*
 * Init Global variables to default values
 */
	opt_dbg   = DBG_NONE;	/* minimum level message for PCIDRVGEN driver */
	chip_AMCC = FALSE;		/* PCI bus interface unspecified */
/*
 * Check the main() arguments
 */ 
	while ((c = getopt_long(argc, argv, "D:#:d:h", longopts, &longind)) != -1)
		{
		switch (c) {
			case 'D' : sscanf(optarg, "%x", &did); 
					   break;
			case '#' : Badr = atoi(optarg);
			           if ((Badr < 0) || (Badr > 5)) {
			              printf("\nWrong Base Adress selection !\n");
			              printf(usage_msg);
			              exit(0);
			              }
			           break;
			case 'd' : opt_dbg = atoi(optarg);
			           if ((opt_dbg < 0) || (opt_dbg > 4)) {
			              printf("\nWrong Debug Level selection !\n");
			              printf(usage_msg);
			              exit(0);
			              }
			           break;
			case 'h' :
			case '?' : 
			default  : printf(usage_msg);
			           printf(help_pcycle);
			           exit(0);
			           break;
			}
		}
/*
 * Set PCI Test Program Environment
 */
	TEST_OPEN((u_short)did);		
/*
 *------------------------ Main User's program --------------------------------*
 */
	CmdType = UNDEFINED;
	Code = UNDEFINED; 
	Step = 0; Arg = 0;
	CodeOp[0] = '\0';
	Line[0] = '\0';
	Loop = 1;

	do { /* while (CmdType != EXIT) */
	
		if (CmdType == UNDEFINED)
			Display_Menu();
		
		if (PCI_Hdr_Adrs[Badr] == 0x0) { /* Badr not assigned by BIOS */
			printf("\n");
			Print_Msg(WARNING, "That Base Address has not been assigned by the system.", -1);
			Print_Msg(INFO,    "\tOperations in that space could break down the machine.", -1); 
			printf("\nBadr#%1d [UNDEF.] ($%X ..%X)> ", \
		                  Badr, PCI_Hdr_Adrs[Badr], PCI_Hdr_Size[Badr]-1); 
			fflush(stdout);
			}
		else {	
			printf("\nBadr#%1d [%s] ($%X -> $%X) +%x> ", \
			          Badr, PCI_Area[PCI_Hdr_Area[Badr]],\
				  PCI_Hdr_Adrs[Badr], PCI_Hdr_Adrs[Badr]+PCI_Hdr_Size[Badr]-1,\
				  Step); 
			fflush(stdout);
			}
	
		/* Read User's choice from keyboard */

 		KbdIn[0] = '\0';
		fgets(KbdIn, sizeof(KbdIn), stdin); 
			
		if ( (KbdIn[0] == '\n') && (CodeOp[0] != '\0') ) { 
			/* replay same cmd with same CodeOp & same parameters */
			}
		else {
			sscanf(KbdIn, "%s", CodeOp);
			strcpy(Line, KbdIn);
			}

		/* Single Read access (8/16/32 bits) from target */
			
		if (strncmp(CodeOp, "rb", 2) == 0) { 
			Match = sscanf(Line, "%*s %x", &Offs);
			if (Match == 1) {
				CmdType = ACCESS_HARD; Code = 1; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else 	
		if (strncmp(CodeOp, "rw", 2) == 0) {
			Match = sscanf(Line, "%*s %x", &Offs);
			if (Match == 1) {
				CmdType = ACCESS_HARD; Code = 2; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else 	
		if (strncmp(CodeOp, "rl", 2) == 0) {
			Match = sscanf(Line, "%*s %x", &Offs);
			if (Match == 1) {
				CmdType = ACCESS_HARD; Code = 3; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}

		/* Single Write access (8/16/32 bits) to target */
	
		else
		if (strncmp(CodeOp, "wb", 2) == 0) {
			Match = sscanf(Line, "%*s %x %x", &Offs, &Data);
			if (Match == 2) {
				CmdType = ACCESS_HARD; Code = 4; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "ww", 2) == 0) {
			Match = sscanf(Line, "%*s %x %x", &Offs, &Data);
			if (Match == 2) {
				CmdType = ACCESS_HARD; Code = 5; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "wl", 2) == 0) {
			Match = sscanf(Line, "%*s %x %x", &Offs, &Data);
			if (Match == 2) {
				CmdType = ACCESS_HARD; Code = 6; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}

		/* Burst Read access (8/16/32 bits) from target */
		
		else
		if (strncmp(CodeOp, "brb", 3) == 0) {
			Match = sscanf(Line, "%*s %x %d", &Offs, &Bcnt);
			if (Match == 2) {
				CmdType = ACCESS_HARD; Code = 9; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "brw", 3) == 0) {
			Match = sscanf(Line, "%*s %x %d", &Offs, &Bcnt);
			if (Match == 2) {			
				CmdType = ACCESS_HARD; Code = 10; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "brl", 3) == 0) {
			Match = sscanf(Line, "%*s %x %d", &Offs, &Bcnt);
			if (Match == 2) {			
				CmdType = ACCESS_HARD; Code = 11; Loop = 1;
				}
			else CmdType = UNDEFINED;
			}
			
		/* Burst Write access (8/16/32 bits) to target */
		
		else
		if (strncmp(CodeOp, "bwb", 3) == 0) {
			if ( (Match = sscanf(Line, "%*s %x %2x %d", &Offs, &Data, &Bcnt)) == 3 ) {
				Ask_Param("bwd");
				CmdType = ACCESS_HARD; Code = 12; Loop = 1;
				}
			else
			if ( (Match = sscanf(Line, "%*s %x %s", &Offs, dma_file)) == 2 ) {
				if (Ask_Param("bwf") != -1) {
					CmdType = ACCESS_HARD; Code = 12; Loop = 1;
					}
				else CmdType = UNDEFINED;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "bww", 3) == 0) {
			if ( (Match = sscanf(Line, "%*s %x %4x %d", &Offs, &Data, &Bcnt)) == 3 ) {
				Ask_Param("bwd");
				CmdType = ACCESS_HARD; Code = 13; Loop = 1;
				}
			else
			if ( (Match = sscanf(Line, "%*s %x %s", &Offs, dma_file)) == 2 ) {
				if (Ask_Param("bwf") != -1) {
					CmdType = ACCESS_HARD; Code = 13; Loop = 1;
					}
				else CmdType = UNDEFINED;
				}
			else CmdType = UNDEFINED;
			}
		
		else	
		if (strncmp(CodeOp, "bwl", 3) == 0) {
			if ( (Match = sscanf(Line, "%*s %x %8x %d", &Offs, &Data, &Bcnt)) == 3 ) {
				Ask_Param("bwd");
				CmdType = ACCESS_HARD; Code = 14; Loop = 1;
				}
			else
			if ( (Match = sscanf(Line, "%*s %x %s", &Offs, dma_file)) == 2 ) {
				if (Ask_Param("bwf") != -1) {
					CmdType = ACCESS_HARD; Code = 14; Loop = 1;
					}
				else CmdType = UNDEFINED;
				}
			else CmdType = UNDEFINED;
			}

		/* Bus Mastering (Read & Write) with AMCC as initiator */
		
		else
		if (chip_AMCC && (strncmp(CodeOp, "bmr", 3) == 0)) {
			CmdType = ACCESS_HARD; Code = 15; Loop = 1;
			}
		else
		if (chip_AMCC && (strncmp(CodeOp, "bmw", 3) == 0)) {
			CmdType = ACCESS_HARD; Code = 16; Loop = 1;
			}

		/* Re-starting of previous command ad libidum */
		
		else
		if (strncmp(CodeOp, "do", 2) == 0) {
			if (strncmp(CodeOp, "dov", 3) == 0)
				Display_Cmd = VERBOSE;
			else	Display_Cmd = MUTE;
			Match = sscanf(Line, "%*s %d", &Loop);
			/** if (Code >= 0) {
				CmdType = ACCESS_HARD; 
				} **/
			}

		/* Read & Write Configuration Header */
	
		else 
		if (strncmp(CodeOp, "rhl", 3) == 0) { /* long format */
			CmdType = CONFIG_SOFT;
			Read_PCI_Config(&header); 
		       	Display_PCI_Header(header, LONG);
			}
		
		else
		if (strncmp(CodeOp, "rh", 2) == 0) { /* short format */
			CmdType = CONFIG_SOFT;
			Read_PCI_Config(&header); 
			Display_PCI_Header(header, SHORT);
			}

		else
		if (chip_AMCC && (strncmp(CodeOp, "wh", 2) == 0)) { 
			CmdType = CONFIG_SOFT;
			Set_PCI_Config(&argusr);
			Write_PCI_Config(&argusr);
			}

		/* Read , Write & Compare NvRam Contents */
		
		else
		if ((strncmp(CodeOp, "rnv", 3) == 0)) {
			CmdType = CONFIG_SOFT;
			if (Ask_Param(CodeOp) != -1) {
				printf("  > Reading NVram ...\n");
				if (Read_AMCC_NVram(Ctrl_NVram, Data_NVram) != -1) {
					if (Ctrl_NVram.file_sav[0] != '\0') {
						printf("  > Writing file `%s' ...\n", Ctrl_NVram.file_sav);
						Store_File_NVram(Ctrl_NVram, Data_NVram);
						}
					Display_AMCC_NVram(Ctrl_NVram, Data_NVram);
					}
				}
			}
		
		else	
		if ((strncmp(CodeOp, "wnv", 3) == 0)) {
			error = 0;
			CmdType = CONFIG_SOFT;
			if (Ask_Param(CodeOp) != -1) {
				if (Ctrl_NVram.file_src[0] != '\0') {
					printf("  > Loading File `%s' ...\n", Ctrl_NVram.file_src);
					if (Load_File_NVram(Ctrl_NVram, Data_NVref) == -1) 
						break;
					}
				printf("  > Writing NVram ...\n");
				if (Write_AMCC_NVram(Ctrl_NVram, Data_NVref) != -1) {
					printf("  > Verifying NVram ...\n");
					Read_AMCC_NVram(Ctrl_NVram, Data_NVram);
					for (i = Ctrl_NVram.start; i < Ctrl_NVram.stop; i++) {
						if (Data_NVram[i] !=  Data_NVref[i]) {
							printf("ERROR ! on reading back NVram at @ %x\n", i);
							printf("\tWritten : %02x - Read : %02x\n", Data_NVref[i], Data_NVram[i]);
							error ++;
							}
						}
					if (!error) printf("\n  NVRAM programmed successfully !\n");	
					}
				}
			}
		
		else	
		if ((strncmp(CodeOp, "cnv", 3) == 0)) {
			error = 0;
			CmdType = CONFIG_SOFT;
			Ask_Param(CodeOp);
			if (Load_File_NVram(Ctrl_NVram, Data_NVref) != -1) {
				if (Read_AMCC_NVram(Ctrl_NVram, Data_NVram) != -1) {
					for (i = Ctrl_NVram.start; i < Ctrl_NVram.stop; i++) {
						if (Data_NVram[i] != Data_NVref[i]) {
							printf("  Address $%04x : Ref. = %02x - Nvram = %02X\n",\
								i, Data_NVref[i], Data_NVram[i]);
							error ++;
							}
						}
					if (error)
						printf("\n  Compare Failed with %d different bytes.\n", error);	
					else
						printf("\n  Compare Successful.\n");
					} /* end of "FOR(i)" statement */	
				}	
			}
				
		/* Download a BIT file into a CUB's virtex */
		
		else	
		if (strncmp(CodeOp, "ldx", 3) == 0) {
			CmdType = CONFIG_SOFT;
			Match = sscanf(Line, "%*s %s", bit_file);
			Load_Virtex(bit_file);
			}

		/* Invoke an interactive shell command */
		
		else
		if (strncmp(CodeOp, "!", 1) == 0) {
			CmdType = CONFIG_SOFT;
			/* Line[0] -= 1; */	/* replace '!' with SPACE */
			system(Line);
			}
			
		/* Miscellaneous Utility commands */
		
		else
		if (strncmp(CodeOp, "#", 1) == 0) {
			CmdType = CONFIG_SOFT;
			Match = sscanf(Line, "%*s %d", &Arg);
			if (Match == 1 && Arg >= 0 && Arg <= 5 ) {
				Badr = Arg;
				if ((Badr == 0) && (chip_AMCC))
					Print_Msg(WARNING, "You 're now pointing on the AMCC S593x's internal operating registers.", -1);
				}
			}
		
		else	
		if (strncmp(CodeOp, "+", 1) == 0) { 
			CmdType = CONFIG_SOFT;
			Match = sscanf(Line, "%*s %x", &Arg);
			if (Match == 1)
				Step = Arg;
			}
			
		/* Same command to execute again */
		
		else
		if (strncmp(CodeOp, "idem", 4) == 0) { 
			/** printf("la meme chose garcon !!!! ");
			printf("CmdType = %d / Code = %d / CodeOp = %c\n",\
			        CmdType, Code, CodeOp[0]); **/
			}
			
		/* Exit `Pcycle' program */
		
		else
		if (CodeOp[0] == 'q') CmdType = EXIT; 

		/* Unknown or Bad command */
		
		else {
			CmdType   = UNDEFINED; 
			Code      = UNDEFINED;
			CodeOp[0] = '\0';
			}
			
		if (CmdType == UNDEFINED)
			Ring_Bell();
			
		/* when requested by user, start here the PCI operation */
		
		if (CmdType == ACCESS_HARD) { /* hardware cycle to execute */

			if (Loop == 0) { /* endless loop required by user */
				Keyboard_Input = FALSE;
				printf("loop on address Offset $%08x ... (type ^C to STOP)\n", Offs);
				}

			for (i = Loop; i > 0 || (Loop == 0 && !Keyboard_Input); i--) {

				error = PCI_Cycle(Code, Badr, Offs, Data, Bcnt);

				if (error == 0 && (Loop == 1 || Display_Cmd)) { 
				
					if (Code == 1)   /* Single byte read */
						printf("S) %08x : %02x = %s\n", Offs, Data&0xff, bin8(Data));
						
					if (Code == 2)  /* Single word read */
						printf("S) %08x : %04x = %s\n", Offs, Data&0xffff, bin16(Data));
						
					if (Code == 3)  /* Single long read */
						printf("S) %08x : %08x = %s\n", Offs, Data, bin32(Data));
						
						
					if (Code == 9) { /* Burst byte read */
						/** printf("\n"); **/
						for (j = 0; j < Bcnt; j ++)
		                			printf("B) %08x : %02x = %s\n", Offs+1*j, Bdma[j], bin8(Bdma[j]));
						free(Bdma);
						}
					if (Code == 10) { /* Burst word read */
						/** printf("\n"); **/
						for (j = 0; j < Bcnt; j ++)
		                			printf("B) %08x : %04x = %s\n", Offs+2*j, Bdma[j], bin16(Bdma[j]));
						free(Bdma);
						}
					if (Code == 11) { /* Burst long read */
						/** printf("\n"); **/
						for (j = 0; j < Bcnt; j ++)
		                			printf("B) %08x : %08x = %s\n", Offs+4*j, Bdma[j], bin32(Bdma[j]));
						free(Bdma);
						}
				
				} /* end of "IF(Loop)" statement */
				
				if (Loop > 1) Offs += Step;
				
			} /* end of "FOR(i)" statement */
					
		} /* end of hardware cycle (CmdType == ACCESS_HARD) */

	} while (CmdType != EXIT);
/*
 *----------------------- End main user's program -----------------------------*
 */ 
	TEST_CLOSE();
		
	exit(0);	/* Exit Test program */
}




/**/
int PCI_Cycle(u_int code, u_int badr, u_int offs, u_int data, u_int count)
/*+*****************************************************************************
 Purpose    : execute a basic PCI hardware cycle in CONF, I/O or MEMory space.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  : ret (0 = OK / -1 = NOTOK)
*****************************************************************************-*/
{
	int ret = 0;
	
	switch (code) {

		case 1 : /* Read a single BYTE ( 8 bits) */
		         ret = Read_PCI(badr, offs, PCIDRV_8BITS, &Data);    
			 break;
		case 2 : /* Read a single WORD (16 bits) */
		         ret = Read_PCI(badr, offs, PCIDRV_16BITS, &Data);    
			 break;
		case 3 : /* Read a single LONG (32 bits) */
		         ret = Read_PCI(badr, offs, PCIDRV_32BITS, &Data);
			 break;

		case 4 : /* Write a single BYTE ( 8 bits) */
		         ret = Write_PCI(badr, offs, PCIDRV_8BITS, data);
			 break;
		case 5 : /* Write a single WORD (16 bits) */
		         ret = Write_PCI(badr, offs, PCIDRV_16BITS, data);
			 break;
		case 6 : /* Write a single LONG (32 bits) */
		         ret = Write_PCI(badr, offs, PCIDRV_32BITS, data);
			 break;

		case 7 : /* Undefined */
		case 8 : /* Undefined */
		         break;

		case 9 : /* Burst Read bytes from chip AMCC as target */
		         Bdma = malloc((size_t)(PCIDRV_8BITS * count)); 
		         ret = Rd_Burst_PCI(badr, offs, PCIDRV_8BITS, count, Bdma);
		         break;

		case 10: /* Burst Read words from chip AMCC as target */
		         Bdma = malloc((size_t)(PCIDRV_16BITS * count)); 
		         ret = Rd_Burst_PCI(badr, offs, PCIDRV_16BITS, count, Bdma);
		         break;

		case 11: /* Burst Read longs from chip AMCC as target */
		         Bdma = malloc((size_t)(PCIDRV_32BITS * count)); 
		         ret = Rd_Burst_PCI(badr, offs, PCIDRV_32BITS, count, Bdma);
		         break;

		case 12: /* Burst Write bytes to chip AMCC as target */	
		         ret = Wr_Burst_PCI(badr, offs, PCIDRV_8BITS, count, Bdma);
			 free(Bdma);
		         break;

		case 13: /* Burst Write words to chip AMCC as target */
		         ret = Wr_Burst_PCI(badr, offs, PCIDRV_16BITS, count, Bdma);
			 free(Bdma);
		         break;

		case 14: /* Burst Write longs to chip AMCC as target */ 		
		         ret = Wr_Burst_PCI(badr, offs, PCIDRV_32BITS, count, Bdma);
			 free(Bdma);
		         break;

		case 15: /* Bus master Read from PCI bus into add-on board */
		         /* ret = DMA_PCI(READ); */
			 break;

		case 16: /* Bus master Write from add-on board into PCI bus */		
		         /* ret = DMA_PCI(WRITE); */
			 break;

		default: break;
		}

	return(ret);	
}


/**/
int Ask_Param(char *cmd)
/*+*****************************************************************************
 Purpose    : Ask user for parameters about the command to execute.
 Description: 
 Arg(s) In  : The command string to ask parameters for.
 Arg(s) Out : 
 Return(s)  : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	char Line[80];
	int  i, p1, p2, val, ret;
	unsigned int *p;
	struct stat statbuf;
	FILE *fp;
	
	if (strncmp(cmd, "rnv", 3) == 0) {	/*** command Read NVram ***/
	
		p1 = Ctrl_NVram.start;
		printf("  First address to read ($%x) ? ", p1);
		fflush(stdout);
		fgets(Line, sizeof(Line), stdin);
		if (Line[0] != '\n') 
			sscanf(Line, "%x", &p1);
		
		p2 = Ctrl_NVram.stop;	
		printf("  Last  address to read ($%x) ? ", p2);
		fflush(stdout);
		fgets(Line, sizeof(Line), stdin);
		if (Line[0] != '\n') 
			sscanf(Line, "%x", &p2);
			
		if (p1 > p2 || p2 >= NVRAM_MAX_SIZE) {
			Print_Msg(ERROR, "wrong address selection.", 1);
			return(-1);
			}
		else {
			p1 = p1 & 0x0000FFF0;	/* start on hexa boundary */
			Ctrl_NVram.start = (u_short)p1;
			Ctrl_NVram.stop  = (u_short)p2;
			}
				
		printf("  Do you wish to save the Readout into a file (n) ? ");
		fflush(stdout);
		fgets(Line, sizeof(Line), stdin);
		
		if (Line[0] == 'y' || Line[0] == 'Y') {
			printf("  Enter the file name (`%s') ? ", Ctrl_NVram.file_sav);
			fflush(stdout);
			fgets(Line, sizeof(Line), stdin);
			if (Line[0] != '\n')
				sscanf(Line, "%s", Ctrl_NVram.file_sav);
			}
		else Ctrl_NVram.file_sav[0] = '\0';

		return(0);

		} /* end of command Read NVram */
	else
		
	if (strncmp(cmd, "wnv", 3) == 0) {	/*** command Write NVram ***/	

		printf("  Select (b)yte or (f)ile to write into NVram (f) ? ");
		fflush(stdout);
		fgets(Line, sizeof(Line), stdin);

		if (Line[0] == 'f' || Line[0] == 'F' || Line[0] == '\n') {
		
			printf("  (Warning : NVram address range programming = [$40 ... $7F])\n");		
			Ctrl_NVram.start = 0x40;
			Ctrl_NVram.stop  = 0x7F;

			printf("  Enter the file name (`%s') ? ", Ctrl_NVram.file_src);
			fflush(stdout);
			fgets(Line, sizeof(Line), stdin);
			
			if (Line[0] != '\n')
				sscanf(Line, "%s", Ctrl_NVram.file_src);
			
			return(0);	
			} 
		else
		if (Line[0] == 'b' || Line[0] == 'B') {

			Ctrl_NVram.file_src[0] = '\0';
			p1 = Ctrl_NVram.start;
			Ctrl_NVram.stop  = Ctrl_NVram.start;
			
			printf("  Address to modify ($%x) ? ", p1);
			fflush(stdout);
			fgets(Line, sizeof(Line), stdin);
			
			if (Line[0] != '\n') {
			
				sscanf(Line, "%x", &p1);
				
				if (p1 >= 0 && p1 < NVRAM_MAX_SIZE) {
					Ctrl_NVram.start = (u_short)p1;
					Ctrl_NVram.stop  = Ctrl_NVram.start;
					}
				else {
					Print_Msg(ERROR, "wrong address selection.", 1);
					return(-1);
					}
				}	

			printf("  Data to write ? ");
			fflush(stdout);
			fgets(Line, sizeof(Line), stdin);
			
			if (Line[0] != '\n') {
				sscanf(Line, "%x", &p1);
				Data_NVref[Ctrl_NVram.start] = (u_char)p1;
				}
			return(0);
			} 
		else
			{
			Print_Msg(ERROR, "undefined operation.", 1);
			/* Ctrl_NVram.file_src[0] = '\0'; */
			return(-1);
			}
		} /* end of command Write NVram */
	else
	
	if (strncmp(cmd, "cnv", 3) == 0) {	/*** command Compare NVram ***/

		printf("  (Warning : NVram address range checking = [$40 ... $7F])\n");	
		Ctrl_NVram.start = 0x40;
		Ctrl_NVram.stop  = 0x7F;
	
		printf("  Enter the file name to check with (`%s') ? ", Ctrl_NVram.file_src);
		fflush(stdout);
		fgets(Line, sizeof(Line), stdin);
		if (Line[0] != '\n')
			sscanf(Line, "%s", Ctrl_NVram.file_src);	
		return(0);
		} /* end of command Compare NVram */
	else
		
	if (strncmp(cmd, "bwf", 3) == 0) { /*** write burst from file ***/	
							
		if ( (fp = fopen(dma_file, "r")) == NULL ) {
			printf("No such file `%s' available.\n", dma_file);
			return(-1);
			}
		else {
			printf("  Opening file `%s' ... \n", dma_file);
			
			if (stat(dma_file, &statbuf)) {
				perror("\tERROR when computing file size ");
				return(-1);
				}
			Bdma = (unsigned int *)calloc(statbuf.st_size, 1);

			i = 0;
			p = Bdma;
			
			while ( (ret = fscanf(fp, "%x", &val)) != EOF ) {

				if (ret == 0) {
					Print_Msg(WARNING, "\tInvalid input data", -1);
					printf("\tat line %d, read ..%x..\n", i+1, val);
					break;
					}
				else {
					*p++ = val;
					i += 1;
					}	
		 		}
					
			printf("  ... %d data read out from file.\n", i); 
			fclose(fp);
			
			Bcnt = i;
			}
		return(0);		
		} 
	else
	
	if (strncmp(cmd,"bwd", 3) == 0) { /*** write burst with inc. pattern ***/	

		printf("  Writing Incremental pattern ... \n");
							
		Bdma = (unsigned int *)calloc(Bcnt, 4);
		
		p = Bdma;
		i = Bcnt;
			
		while (i--) {
			*p++ = Data++;
			}	
			
		return(0);		
		} 

	else 
		return(-1);	/* undefined command string */
}
