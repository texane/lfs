
/*+*****************************************************************************

 File       : PCYCLE.H      
 Project    : 
 Description: compatible avec pcycle.c version 1.5
 Author(s)  : 

 Copyright (c) 2002 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 * Include General Header files
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>   

/*
 * Include Specific Header files
 */

#if 0 /* was */
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "/segfs/linux/csel/util/libtst/V1.4/pci_env_tst.h"
#else /* is */
#include "pcidrvgen.h"
#include "pci_env_tst.h"
#endif

/*
 * Macro substitution
 */
 
#define MY_BADR0_NAME	BADR0	/* BADR0 = 0 ; cf pci_env_tst.h */
#define MY_BADR1_NAME	BADR1
#define MY_BADR2_NAME	BADR2
#define MY_BADR3_NAME	BADR3
#define MY_BADR4_NAME	BADR4
#define MY_BADR5_NAME	BADR5	/* BADR5 = 5 ; cf pci_env_tst.h */

/*
 * Declaration of Library functions 
 */

extern int TEST_OPEN(unsigned short), TEST_CLOSE(void);

extern int Read_PCI_Config(PCIDRV_hdr *), Write_PCI_Config(PCIDRV_arg *);
extern void Set_PCI_Config(PCIDRV_arg *), Display_PCI_Header(PCIDRV_hdr, int);
extern int Dev_Info(unsigned short, unsigned short);

extern int Read_PCI(u_int, u_int, u_int, u_int *);
extern int Write_PCI(u_int, u_int, u_int, u_int);

extern int Rd_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);
extern int Wr_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);

/* extern int DMA_PCI(unsigned char); */

extern int Read_AMCC_NVram(PCITST_nvr, unsigned char *);
extern int Store_File_NVram(PCITST_nvr, unsigned char *);
extern int Write_AMCC_NVram(PCITST_nvr, unsigned char *);
extern int Load_File_NVram(PCITST_nvr, unsigned char *);
extern int Display_AMCC_NVram(PCITST_nvr, unsigned char *);

extern int Load_Virtex(char *);

extern void Wait_and_See(char *);
extern void Print_Msg(char, char *, int);
extern void Clear_Screen(void), Set_Bold(void), Clr_Attr(void), Ring_Bell(void);

extern char *bin32(int), *bin16(int), *bin8(int);

/*
 * Variables specifiques au programme de test
 */
 
static char *msg_dbg[] = {"None", "ERRors", "I/Ofct", "IOCTLs", "Infos"};

PCIDRV_hdr header;
PCIDRV_arg argusr;

unsigned int Data;	/* Memory location for Single access */
unsigned int *Bdma;	/* Buffer          for Burst  access */

unsigned char Data_NVram[NVRAM_MAX_SIZE], /* store AMCC's NVram contents */
              Data_NVref[NVRAM_MAX_SIZE];
PCITST_nvr Ctrl_NVram;

/*
 * User's Section
 */

#define UNDEFINED      -1
#define ACCESS_HARD     1
#define CONFIG_SOFT     2
#define EXIT            0

char *PCI_Area[] = {"MEM", "I/O"};
