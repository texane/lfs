#!/bin/ash

. /etc/rc.d/functions

case "$1" in
start)
	echo -n "Mounting appfs: "
	if [ -e /dev/mmcblk0p4 ]; then
	    mount /dev/mmcblk0p4 /app
	    check_status
	fi
	;;
stop)
        echo -n "Unmounting appfs: "
	umount /app
        check_status
        ;;
restart)
        $0 stop
        $0 start
        ;;
*)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
esac
