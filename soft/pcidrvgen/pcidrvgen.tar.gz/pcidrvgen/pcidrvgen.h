
/*------------------------------------------------------------------------------
 * File:         pcidrvgen.h
 * Project:      PCI Generic Device Drivers
 * Description:  An experimental PCI device driver.
 * Author(s):    Manuel Perez, Philippe Chappelet
 * Original:     Sept 1999
 *
 * $Revision: 2.5 $
 *
 *----------------------------------------------------------------------------*/

#ifndef _PCIDRVGEN_H
#define _PCIDRVGEN_H

/*------------------------------------------------------------------------------
 * Constants
 *----------------------------------------------------------------------------*/

#define PCIDRV_IO_SPACE   1
#define PCIDRV_MEM_SPACE  2

#define PCIDRV_8BITS	  1
#define PCIDRV_16BITS	  2 
#define PCIDRV_32BITS	  4

#define	PCIDRV_HDR_SIZE	  256

#define PCIDRV_SYS_DMA    1
#define PCIDRV_PCI_DMA    2

#define DMA_INIT	1
#define DMA_READ	2

#define SIZE_ARG sizeof(PCIDRV_arg)

#define INFO            1
#define WARNING         2
#define ERROR           3

#define SHORT           0
#define LONG            1

/* 
 * The driver supports various debug output levels. The higher the debug
 * level, the more output is produced.  This debug level can be
 * adjusted at anytime with an ioctl call.
 */

#define DBG_NONE	0
#define DBG_ERRORS	1	/* internal errors of the driver	*/
#define DBG_FUNCS	2	/* entering/leaving driver functions	*/
#define DBG_IOCTLS	3	/* ioctl commands received by the driver*/
#define DBG_INFOS	4	/* general informations			*/
#define DBG_ALWAYS	0

/*------------------------------------------------------------------------------
 * Commands of iotcl() 
 *----------------------------------------------------------------------------*/

/*
 * (according to the file /usr/src/linux/Documentation/ioctl-number.txt,
 * the magic code choosen for this driver is 'e' (hex $65)) like 'e'SRF
 */ 

#define PCIDRV_IOC_MAGIC  'e'

#define PCIDRV_IOC_DEVNB  _IO(PCIDRV_IOC_MAGIC,  1) 
#define PCIDRV_IOC_SCAN   _IOR(PCIDRV_IOC_MAGIC, 2, int) 
  
#define PCIDRV_IOC_INFRD  _IOR(PCIDRV_IOC_MAGIC, 3, int) 
#define PCIDRV_IOC_INFWR  _IOW(PCIDRV_IOC_MAGIC, 4, int)   

#define PCIDRV_IOC_REGRD  _IOR(PCIDRV_IOC_MAGIC, 5, int)
#define PCIDRV_IOC_REGWR  _IOW(PCIDRV_IOC_MAGIC, 6, int)   

#define PCIDRV_IOC_CNFRD  _IOR(PCIDRV_IOC_MAGIC, 7, int)
#define PCIDRV_IOC_CNFWR  _IOW(PCIDRV_IOC_MAGIC, 8, int)   

#define PCIDRV_IOC_DEBUG  _IOW(PCIDRV_IOC_MAGIC, 9, int)

#define PCIDRV_IOC_TBURD  _IOR(PCIDRV_IOC_MAGIC,10, int)
#define PCIDRV_IOC_TBUWR  _IOW(PCIDRV_IOC_MAGIC,11, int)

#define PCIDRV_IOC_DMARD  _IOR(PCIDRV_IOC_MAGIC,12, int)
#define PCIDRV_IOC_DMAWR  _IOW(PCIDRV_IOC_MAGIC,13, int)

#define PCIDRV_IOC_DMABM  _IOW(PCIDRV_IOC_MAGIC,14, int)
#define PCIDRV_IOC_DMATW  _IOW(PCIDRV_IOC_MAGIC,15, int)

/*------------------------------------------------------------------------------
 * Structures passed to ioctl() call according to command
 *----------------------------------------------------------------------------*/

struct _PCIDRV_ioctl_arg 
{
	unsigned int base;   /* reg. BADR[0-5] of chip AMCC S5933 : [1-6] */
	unsigned int offs;   /* offset within BADR                        */
	unsigned int size;   /* size to access (byte/word/long) : [1/2/4] */
	unsigned int data;   /* data to write                             */
	unsigned int *adbuf; /* adr of user buffer for burst data storage */
	unsigned int count;  /* count of burst cycles to perform          */
};

typedef struct _PCIDRV_ioctl_arg PCIDRV_arg;

/*
 *
 */

struct _PCIDRVGEN_private { /* new definition from Kernel 2.4 */
	unsigned int slot;		/* Index of this device in the system */
	unsigned short vid;		/* Vendor Identification */
	unsigned short did;		/* Device Identification */
	unsigned short sub_vid;		/* Subsystem Vendor ID */
	unsigned short sub_did;		/* Subsystem ID */  
	struct pci_bus *bus;            /* Modif. kernel 2.6 for pci_bus_R/W */
	unsigned char bus_num;		/* Bus this device is on */
	unsigned char dev_fct;		/* Function of this device */
	unsigned long badr[6];		/* Base Address registers */
	unsigned long iotype[6];	/* Space(region) type [IO or MEMORY]*/
	unsigned long size[6];  	/* Space(region) size */
	unsigned int irq;		/* Irq line of this device */
	unsigned int irq_count;		/* Count of Irq trigged by this device */
	/* wait_queue_head_t w_queue;	Task queue for PciDrvGen */
	unsigned int usage;		/* ... (to be defined) ... */
	struct _PCIDRVGEN_private *next;
};

typedef struct _PCIDRVGEN_private PCIDRVGEN_private;

/*
 *
 */

typedef unsigned char PCIDRV_hdr[PCIDRV_HDR_SIZE];

#endif	/* _PCIDRVGEN_H */
