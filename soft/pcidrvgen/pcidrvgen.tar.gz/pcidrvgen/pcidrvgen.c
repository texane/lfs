
/*------------------------------------------------------------------------------
 *
 * File:         PCIDRVGEN.C 
 * Project:      PCI Generic Device Drivers
 * Description:  An experimental PCI device driver for Hardware testing.
 * Author(s):    Manuel Perez, Philippe Chappelet
 * Original:     September 1999
 *
 * $Revision: 2.5 $
 * $Log: pcidrvgen.c,v $
 * Revision 2.5  2012/02/06 12:49:30  perez
 * Add DMA Bus Mastering test write
 *
 * Revision 2.4  2011/08/04 13:25:51  perez
 * Port to kernel 2.6.37 (deprecated ioctl() call
 *
 * Revision 2.3  2010/12/03 10:08:36  perez
 * Fix kernel panic bug on insmod
 *
 * Revision 2.2  2010/12/03 10:05:02  perez
 * Port to sysfs/udev + debug print cleanup
 *
 * Revision 2.1  2010/10/28 10:18:50  perez
 * Minimorum port to 2.6.32 kernel, still needing mknod
 *
 * Revision 2.0  2010/10/26 07:35:53  perez
 * Chappelet's version V1.6 28Fev2007
 *
 * Revision 1.6 - 16 Fevrier 2007 - Chappelet
 * - Portage du driver generique vers le Kernel 2.6
 *   (en realite, ce travail a ete realise par F.SEVER) 
 *   Warning : cette version n'est pas compilable pour l'ancien kernel 2.4.
 * - Implementation fonction IOCTL_DMABM pour operation Bus Mastering.
 *
 * Revision 1.5 - 31 Jan 2003 - Chappelet
 * - La version precedente (V1.4) ne se charge plus en memoire (erreur avec la
 *   commande insmod).Pour pallier ce probleme, il a simplement fallu recompiler
 *   le driver pour le rendre compatible avec le nouveau Kernel 2.4.18-4GB
 *   recemment installe sur PCSEL1 (le kernel precedent etait 2.4.4-4GB)
 * - Remplacement de l'include "linux/malloc.h" par "linux/slab.h" dixit gcc.
 *
 * Revision 1.4 - 03 Dec 2002 - Chappelet
 * - Correction 1er Bug ds fct ioremap_nocache() de IOCTL_TBUWR/_TBURD.
 *   (Le 2eme argument doit etre la taille memoire que l'on veut acceder)
 * - Correction 2eme Bug sur fct iounmap() de IOCTL_TBUWR/_TBURD.
 *   (L'argument doit reprendre la meme adresse donnee par ioremap_nocache())
 *
 * Revision 1.3 - 01 Mai 2002 - Chappelet
 * - Renumerotation des Badr de 0 a 5.
 * - Modif parametres appel IOCTL_REGRD.
 * - Implementation du mode Burst (cf IOCTL_TBUWR/_TBURD).
 *
 * Revision 1.2 - 01 Jan 2002 - Chappelet
 * - Compatibilite avec le Kernel 2.4.4-4GB (thanks to F. SEVER).
 * - Le prg 'pcycle.c' n'est plus developpe conjointement avec le driver.
 *
 * Revision 1.1 - 02 Fev 2000 - Chappelet
 * - Add fct_hexa() utilities dans 'pcycle.c'.
 * - Driver inchangee par rapport a 1.0.
 *
 * Revision 1.0 - 02 Fev 2000 - Chappelet
 * - Creation (Joint adVenture with M. PEREZ & myself).
 * - Fully Operational version with IRQs support.
 * - Creation du prg de test 'pcycle.c' pour validation du driver.
 *
 * 
 *  Copyright (c) 1999 by European Synchrotron Radiation Facility,
 *                        Grenoble, France   
 * 
 *----------------------------------------------------------------------------*/

#include <linux/module.h> /* needed by all modules */
#include <linux/kernel.h> /* needed for KERN_ALERT etc. */
#include <linux/init.h>   /* needed for module_init() & module_exit() 
                             macros [not yet use them in 2.4 version] */


/* N.B. For the moment did not explicitely include moduleparam.h
 *      [which exists only for 2.6] and it seems to work anyway
 */
#include <linux/version.h> /* - unlike what Rubini says in LDD3 book (p.26) that
                            *   version.h is automatically included by module.h,
                            *   for 2.6 kernel must include it in order to have 
                            *   LINUX_VERSION_CODE and KERNEL_VERSION() defined 
                            *   so that can test for version!!
                            * - for 2.4 not necessary.
                            */

#include <linux/pci.h>		/* pci-bios functions	*/
#include <linux/interrupt.h>	/* modif V1.6 */

#include <linux/slab.h> 	/* kmalloc, kfree ...	*/ /* modif V1.5 */
#include <linux/errno.h> 	/* error codes 		*/
#include <linux/fs.h>		/* file_operations	*/
#include <linux/delay.h>
#include <linux/ioport.h>

#include <asm/uaccess.h>	/* get_user() put_user()*/
#include <asm/io.h>		/* inb() outb()...	*/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
#include <linux/aer.h>		/* pci_enable_pcie_error_reporting() */
#endif

/*
 * WARNING : due to a limitation in gcc (present at least in 2.7.2.3 and below)
 * and in egcs (all versions), you have to compile any source code that uses
 * inb() outb()... routines with optimisation turned ON (gcc -O1 or higher)
 */

#include "pcidrvgen.h"		/* private ioctl() driver functions */
#include "amcc.h"		/* definition about AMCC S5933 chip */

/*------------------------------------------------------------------------------
 * Global definitions
 *----------------------------------------------------------------------------*/

/*
 * This character module is named "PciDrvGen" and its major number is assigned
 * dynamically when installing and linking it to the Kernel. (cmd insmod)
 * The minor number 0 (special file /dev/pcidrvgen_conf) is defined as the 
 * Configuration device and is used to perform general operations relative
 * to the PCI bus. It doesn't refer to a particular PCI device.
 * The minor numbers, when Non-Null, represent every PCI device found in the
 * system by LINUX on boot (cf struct pci_devices) as /dev/pcidrvgen[i].
 */

#define NAME		"pcidrvgen"	/* name of device in /proc/devices */
#define MINOR_CONF	0		/* minor number	for Config. device */

/* 
 * The driver supports various debug output levels.
 * The higher the debug level is, the more output is produced.
 * This debug level can be adjusted at anytime with an ioctl call.
#define DBG(l,x)        if (pcidrv_dbg >= l) x
 */
#define DBG(l,msg, args...)  if (pcidrv_dbg >= l) printk(KERN_INFO NAME ":%s: " msg,__FUNCTION__, ## args)

MODULE_DESCRIPTION("PCI generic driver");
MODULE_AUTHOR("Manuel Perez and Philippe Chappelet");
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
MODULE_LICENSE("Dual BSD/GPL");
#endif

/*------------------------------------------------------------------------------
 * Global resources
 *----------------------------------------------------------------------------*/

static int pcidrv_dbg;		/* debug level for printk()   	*/
static int pcidrv_major;	/* dynamic major number   	*/
static int pci_board_count; /* total number of PCI devices	*/

static u_int *dma_buf; 		/* data buffer for burst operations */
static int    dma_buf_size;

static PCIDRVGEN_private *pcidrvgen_info_ptr = NULL;	/* cf pcidrvgen.h */

/*------------------------------------------------------------------------------

  ..._private          ..._private           ..._private
   ---------           ---------              ---------
  |  slot   | <--     |  slot   | <--        |         | <-- *pcidrvgen_info_ptr
   ---------     |     ---------     |       |         |
  |  badr0  |    |    |  badr0  |    |       |         |
  |  .....  |    |    |  .....  |    |       |         |
  |  badr5  |    |    |  badr5  |    |       |         |
   ---------     |     ---------     |       |         |
  |   irq   |    |    |   irq   |    |       |         |
   ---------     |     ---------     |        --------- 
  |  NULL   |    |___ |  *next  |    |__ ....|  *next  | 
   ---------           ---------              --------- 
   1rst card           2nd card     ......    nth card

------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
 * List of entry points in the module
 *----------------------------------------------------------------------------*/

static int  __init pcidrvgen_init(void);
static void __exit pcidrvgen_exit(void);

static int pcidrvgen_open  (struct inode *inode, struct file *file);
static int pcidrvgen_close (struct inode *inode, struct file *file);
#ifdef HAVE_UNLOCKED_IOCTL
static long pcidrvgen_ioctl (struct file *file,
                            unsigned int cmd, unsigned long user_arg);
#else
static int  pcidrvgen_ioctl (struct inode *inode, struct file *file,
                            unsigned int cmd, unsigned long user_arg);
#endif

/*------------------------------------------------------------------------------
 * List of private functions
 *----------------------------------------------------------------------------*/

static PCIDRVGEN_private *set_ptr_priv_data(unsigned int slot);

/*------------------------------------------------------------------------------
 * Kernel table with entry points into the module
 * (ie. what to do when specific file-operation occurs)
 *----------------------------------------------------------------------------*/

static struct file_operations pcidrvgen_fops = {
	owner:          THIS_MODULE,
#ifdef HAVE_UNLOCKED_IOCTL
	unlocked_ioctl: pcidrvgen_ioctl,     /* ioctl 	*/
#else
	ioctl:          pcidrvgen_ioctl,     /* ioctl 	*/
#endif
	open:           pcidrvgen_open,      /* open 	*/
	release:        pcidrvgen_close,     /* release	*/
};


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0)
module_init(pcidrvgen_init);
module_exit(pcidrvgen_exit);
#endif


/*--------------------------------------------------------------------------
 * pcidrvgen_class class structure.
 *--------------------------------------------------------------------------*/
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
static struct class *pcidrvgen_class;
#endif


/*------------------------------------------------------------------------------
 * Function:    pcidrv_irq_handler()
 * 
 * Description: Interrupt handler for the BIOS IRQ generated by a PCI device.
 *
 * NOTE : This Irq Handler is NO more generic (as previously foreseen).
 *        Nevertheless, we can try to do some basic things to slightly test an
 *        Irq Handling (for a specific board to debug)
 *
 *        At last, if this Int. handler doesn't fit your needs, write your own.
 *----------------------------------------------------------------------------*/

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,19)
static irqreturn_t pcidrv_irq_handler(int irq, void *dev_id)
#else
static irqreturn_t pcidrv_irq_handler(int irq, void *dev_id, struct pt_regs *regs)
#endif
{
	PCIDRVGEN_private *pcidrvgen_info;
		
	/* DBG(DBG_INFOS, "entering IRQ handler"); */

	/* Get a ptr on the private info area of the interrupting PCI dev. */
	pcidrvgen_info = dev_id;

	/** if (pcidrvgen_info->did == ESRF_ID_CFBUS) { **/

		/* Read IRQ status register, Check the source & Clear the IT */
	
		/** pcidrvgen_info->irq_count ++;
		
		} **/
/* #if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0) */
	return 0;
/* #endif */
}






/*------------------------------------------------------------------------------
 * Function:    init_module()
 * 
 * Description: Mandatory function for a module, called when loading dynamically
 * 		the module in running kernel with "insmod".
 * 
 * Return:	non zero, if the initialization failed and the module
 *		could not be loaded.
 * 
 *----------------------------------------------------------------------------*/

static int pcidrvgen_init(void)
{
	int i;
	int minor;

	struct pci_dev *ptr_dev;

	PCIDRVGEN_private *pcidrvgen_info;

	/* Default debug level for printing our debug messages */
	pcidrv_dbg = DBG_NONE;	/* Minimorum messaging */
	pcidrv_dbg = DBG_INFOS; /* Maximorum messaging */
	pcidrv_dbg = DBG_FUNCS;

	DBG(DBG_ALWAYS,"$Revision: 2.5 $\n");

	/* Create an entry in sysfs: /sys/class/xxxx */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
	pcidrvgen_class = class_create(THIS_MODULE, NAME);
	if(IS_ERR(pcidrvgen_class))
	{
		DBG(DBG_ERRORS, "can't create class\n");
		return -EFAULT;
	}
#endif

	/* Ask for a Major number (given by the Kernel itself) */
	pcidrv_major = register_chrdev(0, NAME, &pcidrvgen_fops);
	if (pcidrv_major < 0) 
	{
		DBG(DBG_ERRORS, "can't get a major number\n");
		return -EFAULT;
	}
	DBG(DBG_INFOS, "major number = %d\n", pcidrv_major);

	/* Create an entry in sysfs: /sys/class/xxxx/xxxxNN */
	/* This will replace, with the help of udev, the mknod */
	minor = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
	device_create(pcidrvgen_class,
		NULL,
		MKDEV(pcidrv_major,minor),
		NULL,
		"pcidrvgen_conf");
#endif

	/* Scan the list of PCI devices built by the Kernel during Linux boot
	   and fill the private data structure of every PCI device */
        ptr_dev = (struct pci_dev *)NULL;
	
	/* TODO: can replace later the first PCI_ANY_ID in the calls to
         *       pci_get_device() with PCI_VENDOR_ID_AMCC since for us 
         *       most interesting are devices with AMCC_VID.
         */
	ptr_dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID,ptr_dev);
        while(ptr_dev != (struct pci_dev *)NULL) 
	{
	
		/*
		 * Next command could be done also later. According to the book
		 * of A.Rubini pci_enable_device() must be called before
		 * IO (or MEM) operations are performed.
		 *
		 * By using it, it causes a crash!! even if select only
		 * our CUB-based devices. So avoid using pci_enable_device()
		 *
		 */
		
		pcidrvgen_info = kmalloc(sizeof(PCIDRVGEN_private), GFP_KERNEL);
		if (pcidrvgen_info == NULL) 
		{
			DBG(DBG_ERRORS, "error on kmalloc()\n");
			return -ENOMEM;
		}
			
		memset(pcidrvgen_info, 0, sizeof(PCIDRVGEN_private)); 

		pcidrvgen_info->slot    = ++pci_board_count;

		pcidrvgen_info->bus     = ptr_dev->bus;

		pcidrvgen_info->bus_num = ptr_dev->bus->number;
		pcidrvgen_info->dev_fct = ptr_dev->devfn;
		
		pcidrvgen_info->vid     = ptr_dev->vendor;
		pcidrvgen_info->did     = ptr_dev->device;
		pcidrvgen_info->sub_vid = ptr_dev->subsystem_vendor;
		pcidrvgen_info->sub_did = ptr_dev->subsystem_device;
				
		for (i = 0; i < 6; i++) 
		{
			pcidrvgen_info->badr[i] = pci_resource_start(ptr_dev,i);
			pcidrvgen_info->size[i] = pci_resource_len(ptr_dev,i); 
			

			if (pci_resource_flags(ptr_dev, i) & IORESOURCE_IO) 
				pcidrvgen_info->iotype[i] = PCI_BASE_ADDRESS_SPACE_IO;
			else 
			if (pci_resource_flags(ptr_dev, i) & IORESOURCE_MEM) {
				pcidrvgen_info->iotype[i] = PCI_BASE_ADDRESS_SPACE_MEMORY;
				if (!request_mem_region(pcidrvgen_info->badr[i],
				   pcidrvgen_info->size[i], NAME)) {
					DBG(DBG_ERRORS, "request_mem_region failed on board %d", minor);
				}
			}
		}

		pcidrvgen_info->irq = ptr_dev->irq;

		DBG(DBG_INFOS, "   %2d) Vendor = 0x%04x / Device = 0x%04x\n",
		        pcidrvgen_info->slot, ptr_dev->vendor, ptr_dev->device);
				
		pcidrvgen_info->next = pcidrvgen_info_ptr;
		pcidrvgen_info_ptr = pcidrvgen_info;

		/* Create an entry in sysfs: /sys/class/xxxx/xxxxNN */
		/* This will replace, with the help of udev, the mknod */
		minor = pci_board_count;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
		device_create(pcidrvgen_class,
			NULL,
			MKDEV(pcidrv_major,minor),
			NULL,
			"pcidrvgen%d",
			minor);
#endif
                /* 
 		 * MP 02Dec2010: the reference count for "ptr_dev" is
 		 * always done by pci_get_device() so the call to
		 * pci_dev_put() is not needed and can cause a kernel
		 * panic after several module reload cycle
		 *
                pci_dev_put(ptr_dev);
                 */
		ptr_dev = pci_get_device(PCI_ANY_ID, PCI_ANY_ID,ptr_dev);
	} /* end of while (ptr_dev != (struct pci_dev *) NULL); */

	if (pci_board_count == 0) {
		DBG(DBG_ERRORS, "no device on PCI bus\n");
		return -ENODEV;
	} else {                    
		DBG(DBG_INFOS,"found %d devices\n",pci_board_count);
	}


	/* Normal end, the module can be loaded in running kernel */
	DBG(DBG_FUNCS, "loading successful\n");

	return(0);	/* normal end, the module can be loaded */
}


/*------------------------------------------------------------------------------
 * Function:    cleanup_module()
 * 
 * Description: Mandatory function for a module, called when removing
 * 		the module from running kernel with "rmmod".
 * 
 *----------------------------------------------------------------------------*/
 
static void __exit pcidrvgen_exit(void)
{
	PCIDRVGEN_private *pcidrvgen_info;
	int minor;

	DBG(DBG_ALWAYS, "entering\n");

	/* For all allocated devices */
	while ((pcidrvgen_info = pcidrvgen_info_ptr)) {
		/* Get next device info */
		pcidrvgen_info_ptr = pcidrvgen_info_ptr->next;
	
		/* Remove entry in sysfs: /sys/class/xxxx/xxxxNN */
 		minor = pcidrvgen_info->slot;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
		device_destroy(pcidrvgen_class, MKDEV(pcidrv_major,minor));
#endif

		/* Free allocated memory */
		kfree(pcidrvgen_info);		
	}

	/* Remove entry in sysfs: /sys/class/xxxx/xxxxNN */
	minor = 0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
	device_destroy(pcidrvgen_class, MKDEV(pcidrv_major,minor));
#endif

	/* Remove entry in sysfs: /sys/class/xxxx */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
	class_destroy(pcidrvgen_class);
#endif

	/* Unregister the module from the kernel */
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,9)
	unregister_chrdev(pcidrv_major, NAME);
#else
	if (unregister_chrdev(pcidrv_major, NAME) < 0)
		DBG(DBG_ERRORS, "can't unregister major %d\n", pcidrv_major);
#endif

	DBG(DBG_FUNCS, "module removed from kernel\n");
}





/*------------------------------------------------------------------------------
 * Function:    pcidrvgen_open()
 * 
 * Description: This function is called when a program open 
 *		the device descriptor associated with this module
 *		using the open() function.
 * 
 *----------------------------------------------------------------------------*/

static int pcidrvgen_open (struct inode *inode, struct file *file)
{
	int ret = 0;
	PCIDRVGEN_private *pcidrvgen_info;

	int minor = MINOR(inode->i_rdev); 

	DBG(DBG_FUNCS, "minor = %d\n", minor);
 
	/* 
	 * Increment the usage counter (ie the number of program using
	 * this module) to make sure that the module won't be removed
	 * from the kernel while it's used by a program (the rmmod fails
	 * if the usage counter is non null).
	 */

	/* MOD_INC_USE_COUNT; */

	if (minor == MINOR_CONF) {
		DBG(DBG_ERRORS, "DEV_CONF\n");
		}
	else {
		/* Set a data pointer on the private area of the PCI device */
		if ((pcidrvgen_info = set_ptr_priv_data(minor)) == NULL) {
			DBG(DBG_ERRORS, "illegal PCI dev\n");
			return -EINVAL;
		}

		/* Install the IRQ handler if necessary */
		if (pcidrvgen_info->irq) {
			DBG(DBG_INFOS, "IRQ = %d\n", pcidrvgen_info->irq);
		
			ret = request_irq(pcidrvgen_info->irq, 
			                  pcidrv_irq_handler,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18)
			                  IRQF_SHARED,
#else
			                  SA_SHIRQ,
#endif
                                          NAME,
                                          (void *)(pcidrvgen_info));

			if (ret < 0) {
				DBG(DBG_ERRORS, "IRQ %d not free\n", pcidrvgen_info->irq);
				return ret;
				}
			}
		}

	DBG(DBG_FUNCS, "leaving\n");

	return 0;	/* normal end */
}

/*------------------------------------------------------------------------------
 * Function:    pcidrvgen_close()
 * 
 * Description: This function is called when a program closes
 *		the device descriptor associated with this module
 *		using the close() function.
 *		(REM : after kernel 2.2 this function may fail)
 * 
 *----------------------------------------------------------------------------*/

static int  pcidrvgen_close (struct inode *inode, struct file *file)
{
	PCIDRVGEN_private *pcidrvgen_info;

        int minor = MINOR(inode->i_rdev);

	DBG(DBG_FUNCS, "minor = %d\n", minor);

	/*
	 * Decrement the usage counter (ie the number of program using
	 * this module), otherwise once an open() has been done it will
	 * be impossible to remove the module from the kernel because
	 * this one would think that it is still used).
	 */

	/* MOD_DEC_USE_COUNT; */

	if (minor == MINOR_CONF) {
		DBG(DBG_ERRORS, "DEV_CONF\n");
		}
	else {
		if ((pcidrvgen_info = set_ptr_priv_data(minor)) == NULL) {
			DBG(DBG_ERRORS, "illegal PCI dev\n");
			return -EINVAL;
			}
			
		/* Remove the IRQ handler */	
		if (pcidrvgen_info->irq) 
			free_irq(pcidrvgen_info->irq, pcidrvgen_info);

		} /* end of if_else(minor == MINOR_CONF) */

	DBG(DBG_FUNCS, "leaving\n");

	return(0);
}


/*------------------------------------------------------------------------------
 * Function:    pcidrvgen_ioctl()
 * 
 * Description: This function is called when a program does an ioctl() on
 *		the device descriptor associated with this module.
 * 
 *----------------------------------------------------------------------------*/

#ifdef HAVE_UNLOCKED_IOCTL
static long pcidrvgen_ioctl (struct file *file,
                             unsigned int cmd, unsigned long user_arg)
{
	struct inode *inode = file->f_dentry->d_inode;
#else
static int  pcidrvgen_ioctl (struct inode *inode, struct file *file,
                             unsigned int cmd, unsigned long user_arg)
{
#endif
	int i, time_out, ret = 0, n;
        unsigned char *ptr_uchar;
	unsigned long  pci_adr, pci_dat;

	unsigned char  *vptr8,  *vmptr_char; /*  8-bits ptr in virtual memory */
	unsigned short *vptr16, *vmptr_short;/* 16-bits ptr in virtual memory */
	unsigned int   *vptr32, *vmptr_int;  /* 32-bits ptr in virtual memory */
	
	unsigned int   user_buf_size;

	PCIDRV_arg arg;
	PCIDRV_hdr hdr;

	PCIDRVGEN_private dev_info, *pcidrvgen_info = NULL;

	int minor = MINOR(inode->i_rdev); /* retrieve minor number of the dev */

	DBG(DBG_FUNCS, "minor = %d\n", minor);

	/* 
	 *---------------- Check command vs minor number ----------------------*
	 */
	
	switch(cmd) {

	/* General Commands, only for the not real PCI device (minor == 0) */

	case PCIDRV_IOC_DEVNB:
	case PCIDRV_IOC_SCAN :
	
		if (minor != MINOR_CONF) {
			DBG(DBG_ERRORS, "not the DEV_CONF\n");
			return -EPERM;
			}
		break;

	/* Specific Commands, for real PCI devices (minor != 0) */

	case PCIDRV_IOC_INFRD:
	case PCIDRV_IOC_INFWR:
	case PCIDRV_IOC_REGRD:
	case PCIDRV_IOC_REGWR:
	case PCIDRV_IOC_CNFRD:
	case PCIDRV_IOC_CNFWR:
	case PCIDRV_IOC_DMARD:
	case PCIDRV_IOC_DMAWR:
	case PCIDRV_IOC_TBURD:	
	case PCIDRV_IOC_TBUWR:
        case PCIDRV_IOC_DMABM:
        case PCIDRV_IOC_DMATW:

		if (minor == MINOR_CONF) {
			DBG(DBG_ERRORS, "DEV_CONF is not a real device\n");
			return -EPERM;
			}
		else {
			/* Set a data ptr on the private area of PCI dev. */
			if ((pcidrvgen_info = set_ptr_priv_data(minor)) == NULL)
				{
				DBG(DBG_ERRORS, "illegal PCI dev\n");
				return -EINVAL;
				}
			}
		break;

	/* Miscellaneous Commands allowed regardless of the selected device */
	
	case PCIDRV_IOC_DEBUG:
		break;

	default:
		DBG(DBG_ERRORS, "unknown IOCTL() command\n");
		return -EINVAL;	

	} /* end of switch(cmd) */


	/*
	 *---------------- Processing of the current command ------------------*
	 */
	
	switch(cmd) { 

	case PCIDRV_IOC_DEVNB:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_DEVNB\n");
		ret = pci_board_count;
		break; 

	case PCIDRV_IOC_SCAN:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_SCAN\n");

		if (copy_from_user(&dev_info, (PCIDRVGEN_private *)user_arg, 
		                   sizeof(PCIDRVGEN_private) )) 
		{
			DBG(DBG_ERRORS, "copy_from_user() error\n");
			return -EFAULT;
		}

		/* Check the PCI device number resquested */
		if (dev_info.slot < 1 || dev_info.slot > pci_board_count) 
		{
			DBG(DBG_ERRORS, "bad devnum range");
			return -EINVAL;
		}
	
		/* Read the PCI device's informations */
		if ((pcidrvgen_info = set_ptr_priv_data(dev_info.slot)) != NULL)
		{
			dev_info.vid = pcidrvgen_info->vid;
			dev_info.did = pcidrvgen_info->did;
			DBG(DBG_INFOS, "VID:0x%04x DID:0x%04x", 
				dev_info.vid, dev_info.did);
		}
		else 
		{
			DBG(DBG_ERRORS, "Illegal PCI dev");
			return -ENODEV;
		}

		/* Convert addresses from kernel memory space to user one */
		if (copy_to_user((PCIDRVGEN_private *)user_arg, &dev_info, 
		                sizeof(PCIDRVGEN_private))) {
			DBG(DBG_ERRORS, "copy_to_user() error");
			return -EFAULT;
			}

		break;

	case PCIDRV_IOC_INFRD:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_INFRD");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&dev_info, (PCIDRVGEN_private *)user_arg, 
		                   sizeof(PCIDRVGEN_private) )) {
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;
			}

		/* Read the PCI device's informations */
			
		for (i = 0; i <= 5; i++) {
			dev_info.size[i] = pcidrvgen_info->size[i];
			dev_info.iotype[i] = pcidrvgen_info->iotype[i];
			}
		
		dev_info.irq_count = pcidrvgen_info->irq_count;

		/* Convert addresses from kernel memory space to user one */
		if (copy_to_user((PCIDRVGEN_private *)user_arg, &dev_info, 
		                sizeof(PCIDRVGEN_private))) {
			DBG(DBG_ERRORS, "copy_to_user() error");
			return -EFAULT;
			}

		break;

	case PCIDRV_IOC_INFWR:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_INFWR");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&dev_info, (PCIDRVGEN_private *)user_arg, 
		                   sizeof(PCIDRVGEN_private) )) {
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;
			}

		/* Write the PCI device's informations */
			
		pcidrvgen_info->irq_count = dev_info.irq_count;

		break;

	case PCIDRV_IOC_REGRD:  
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_REGRD");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_from_user() error"); 
			return -EFAULT; 
			}

		/* Check the base address (must be 1 out of the 6 available) */
		if ((arg.base < 0) || (arg.base > 5)) {
			DBG(DBG_ERRORS, "wrong adr_base\n");
			return -EINVAL; 
			}

		/* Calculate the PCI address to access */
		pci_adr  = pcidrvgen_info->badr[arg.base];
		pci_adr += arg.offs;   

		DBG(DBG_INFOS, "phys.@=0x%08lx", pci_adr);

		/*
	 	 * The I/O port addresses are not accessed in the same way than
		 * the memory addresses. Each of them has its own system calls.
		 * Accessing memory space requires also an address translation
		 * from physical address (given by the BIOS to the board and
		 * record in the configuration header) to translated virtual
		 * address (the only one known by the CPU ??).
		 */

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_IO) {

			DBG(DBG_INFOS, "I/O space");

			switch (arg.size) {

			case PCIDRV_8BITS: /* read a char from the IO port */
				arg.data = inb(pci_adr); 
				break;
			case PCIDRV_16BITS: /* read a short from the IO port */
				arg.data = inw(pci_adr);
				break;
			case PCIDRV_32BITS: /* read an int from the IO port */
				arg.data = inl(pci_adr);
				break;
			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_MEMORY) {


			switch (arg.size) { 

			case PCIDRV_8BITS: 
				DBG(DBG_INFOS, "size:  8bits"); 
				if (arg.offs) {	/************* BUG Linux 2.4.4 *************/
				/* translate phys. addr to virtual addr */
				vmptr_char = (char *)ioremap_nocache(pci_adr, sizeof(char));
				/* read a byte from the virtual addr */ 
				arg.data = readb(vmptr_char); 
				/* unmap when no more needed */ 
				iounmap(vmptr_char);
				}
				else return -EINVAL;
				break;

			case PCIDRV_16BITS:   
				DBG(DBG_INFOS, "size: 16bits"); 
				/* translate phys. addr to virtual addr */
				vmptr_short = (short *)ioremap_nocache(pci_adr, sizeof(short));
				/* read a short from the virtual addr */
				arg.data = readw(vmptr_short);  
				/* unmap when no more needed */     
				iounmap(vmptr_short);
				break;     

			case PCIDRV_32BITS:    
				DBG(DBG_INFOS, "size: 32bits %d",sizeof(int)); 
				/* translate phys. addr to virtual addr */     
				vmptr_int = (int *)ioremap_nocache(pci_adr, sizeof(int)); 
				DBG(DBG_INFOS, "vmpptr_int: 0x%08x",vmptr_int); 
				/* read an int from the virtual addr */
/*
				arg.data = readl(vmptr_int);  
*/
				arg.data = ioread32(vmptr_int);  
				/* unmap when no more needed */  
				iounmap(vmptr_int); 
				break;

			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		DBG(DBG_INFOS, "data=0x%08x", arg.data);

		/* Convert addresses from kernel memory space to user space */
		if (copy_to_user((PCIDRV_arg *)user_arg, &arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_to_user() error"); 
			return -EFAULT;   
			}

		break; /* end of case PCIDRV_IOC_REGRD */

	case PCIDRV_IOC_REGWR:  
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_REGWR");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_from_user() error"); 
			return -EFAULT; 
			}

		/* Check the base address (must be 1 out of the 6 available) */
		if ((arg.base < 0) || (arg.base > 5)) {
			DBG(DBG_ERRORS, "wrong adr_base");
			return -EINVAL; 
			}

		/* Calculate the PCI address to access */
		pci_adr = pcidrvgen_info->badr[arg.base];
		pci_adr += arg.offs;   

		DBG(DBG_INFOS, "phys.@=0x%08lx", pci_adr);

		/*
	 	 * The I/O port addresses are not accessed in the same way than
		 * the memory addresses. Each of them has its own system calls.
		 * Accessing memory space requires also an address translation
		 * from physical address (given by the BIOS to the board and
		 * record in the configuration header) to translated virtual
		 * address (the only one known by the CPU ??).
		 */

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_IO) {

			DBG(DBG_INFOS, "I/O space");

			switch (arg.size) {

			case PCIDRV_8BITS: /* write a char to the IO port */
				outb(arg.data, pci_adr); 
				break;
			case PCIDRV_16BITS: /* write a short to the IO port */
				outw(arg.data, pci_adr);
				break;
			case PCIDRV_32BITS: /* write an int to the IO port */
				outl(arg.data, pci_adr);
				break;
			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_MEMORY) {

			DBG(DBG_INFOS, "MEMory space"); 

			switch (arg.size) { 

			case PCIDRV_8BITS: 
				if (arg.offs) {	/************* BUG Linux 2.4.4 *************/
				/* translate phys. addr to virtual addr */
				vmptr_char = (char *)ioremap(pci_adr, sizeof(char));
				/* write a byte to the virtual addr */ 
				writeb(arg.data, vmptr_char); 
				/* unmap when no more needed */ 
				iounmap(vmptr_char);
				}
				else return -EINVAL;
				break;

			case PCIDRV_16BITS:   
				/* translate phys. addr to virtual addr */
				vmptr_short = (short *)ioremap(pci_adr, sizeof(short));
				/* write a short to the virtual addr */
				writew(arg.data, vmptr_short);  
				/* unmap when no more needed */     
				iounmap(vmptr_short);
				break;     

			case PCIDRV_32BITS:    
				/* translate phys. addr to virtual addr */     
				vmptr_int = (int *)ioremap(pci_adr, sizeof(int)); 
				/* write an int to the virtual addr */
				writel(arg.data, vmptr_int);  
				/* unmap when no more needed */  
				iounmap(vmptr_int); 
				break;

			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		break; /* end of case PCIDRV_IOC_REGWR */
		
	case PCIDRV_IOC_TBURD:	/* Target BUrst ReaD on MEMory area only */
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_TBURD");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG)) {
			DBG(DBG_ERRORS, "copy_from_user() error"); 
			return -EFAULT; 
			}

		/* Check the base address (must be 1 out of the 6 available) */
		if ((arg.base < 0) || (arg.base > 5)) {
			DBG(DBG_ERRORS, "wrong adr_base");
			return -EINVAL; 
			}

		/* Calculate the PCI address to access */
		pci_adr = pcidrvgen_info->badr[arg.base];
		pci_adr += arg.offs;   

		DBG(DBG_INFOS, "phys.@=0x%08lx", pci_adr);

		/* Prepare the buffer to store the read values */
		dma_buf = (int *)kmalloc(PCIDRV_32BITS*arg.count, GFP_DMA);
		memset(dma_buf, 0, PCIDRV_32BITS*arg.count);

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_IO) {

			DBG(DBG_INFOS, "I/O space");

			switch (arg.size) {

			case PCIDRV_8BITS: /* read a char from the IO port */
				for (i = 0; i < arg.count; i ++)
					((char  *)(dma_buf))[i] = inb(pci_adr + i); 
				break;
			case PCIDRV_16BITS: /* read a short from the IO port */
				for (i = 0; i < arg.count; i ++)
					((short  *)(dma_buf))[i] = inw(pci_adr + 2*i);
				break;
			case PCIDRV_32BITS: /* read an int from the IO port */
				for (i = 0; i < arg.count; i ++)
					((int  *)(dma_buf))[i] = inl(pci_adr + 4*i);
				break;
			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_MEMORY) {

			DBG(DBG_INFOS, "MEM space");

			switch (arg.size) { 

			case PCIDRV_8BITS: 
				if (arg.offs) {	/************* BUG Linux 2.4.4 *************/
				/* translate phys. addr to virtual addr */
	vmptr_char = (char *)ioremap_nocache(pci_adr, arg.count*sizeof(char));
				vptr8 = vmptr_char;
				/* read bytes from the virtual addr */
				for (i = 0; i < arg.count; i ++) 
					((int *)(dma_buf))[i] = readb(vptr8++); 
				/* unmap when no more needed */ 
				iounmap(vmptr_char); 
				}
				else return -EINVAL;
				break;

			case PCIDRV_16BITS:   
				/* translate phys. addr to virtual addr */
	vmptr_short = (short *)ioremap_nocache(pci_adr, arg.count*sizeof(short));
				vptr16 = vmptr_short;
				/* read shorts from the virtual addr */
				for (i = 0; i < arg.count; i ++)
					((int  *)(dma_buf))[i] = readw(vptr16++);  
				/* unmap when no more needed */     
				iounmap(vmptr_short);
				break;     

			case PCIDRV_32BITS:    
				/* translate phys. addr to virtual addr */     
	vmptr_int = (int *)ioremap_nocache(pci_adr, arg.count*sizeof(int));
				vptr32 = vmptr_int;
				/* read ints from the virtual addr */
				for (i = 0; i < arg.count; i ++)
		 			((int  *)(dma_buf))[i] = readl(vptr32++); 
				/* unmap when no more needed */  
				iounmap(vmptr_int); 
				break;

			default:DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		/* DBG(DBG_INFOS, "data=0x%08x", arg.data); */

		/* Put DMA buffer from kernel memory space to user one */
		for(i = 0; i < arg.count; i++)
			((int *)(arg.adbuf))[i] = ((int *)dma_buf)[i];
		kfree(dma_buf);
			
		break; /* end of case PCIDRV_IOC_TBURD */

	case PCIDRV_IOC_TBUWR:	/* Target BUrst WRite */
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_TBUWR");

		/* Convert addresses from user memory space to kernel space */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG)) {
			DBG(DBG_ERRORS, "copy_from_user() error"); 
			return -EFAULT; 
			}

		/* Check the base address (must be 1 out of the 6 available) */
		if ((arg.base < 0) || (arg.base > 5)) {
			DBG(DBG_ERRORS, "wrong adr_base");
			return -EINVAL; 
			}

		/* Calculate the PCI address to access */
		pci_adr = pcidrvgen_info->badr[arg.base];
		pci_adr += arg.offs;   

		DBG(DBG_INFOS, "phys.@=0x%08lx", pci_adr);

		/* Allocate the buffer to store the data to write */
		if (arg.adbuf == 0)
			return -EINVAL;
		else {
			dma_buf = (u_int *)kmalloc(PCIDRV_32BITS*arg.count, GFP_DMA);
			memset(dma_buf, 0, PCIDRV_32BITS*arg.count);
			memcpy(dma_buf, (u_int *)arg.adbuf, PCIDRV_32BITS*arg.count);
			}
			
		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_IO) {

			DBG(DBG_INFOS, "I/O space\n");

			switch (arg.size) {

			case PCIDRV_8BITS: /* write a char to the IO port */
				for (i = 0; i < arg.count; i ++)
					outb( ((char *)(dma_buf))[i], pci_adr + i ); 
				break;

			case PCIDRV_16BITS: /* write a short to the IO port */
				for (i = 0; i < arg.count; i ++)
					outw( ((short *)(dma_buf))[i], pci_adr + 2*i ); 
				break;

			case PCIDRV_32BITS: /* write an int to the IO port */
				for (i = 0; i < arg.count; i ++)	
					outl( ((int *)(dma_buf))[i], pci_adr + 4*i ); 
				break;

			default:
				DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		if (pcidrvgen_info->iotype[arg.base] == PCI_BASE_ADDRESS_SPACE_MEMORY) {

			DBG(DBG_INFOS, "MEM space");

			switch (arg.size) { 

			case PCIDRV_8BITS:
				if (arg.offs) {	/************* BUG Linux 2.4.4 *************/
				/* translate phys. addr to virtual addr */
	vmptr_char = (char *)ioremap_nocache(pci_adr, arg.count*sizeof(char));
				vptr8 = vmptr_char;
				/* write bytes to the virtual addr */ 
				for (i = 0; i < arg.count; i ++) 
					writeb( ((char *)(dma_buf))[i], vptr8++);
				/* unmap when no more needed */ 
				iounmap(vmptr_char); 
				}
				else return -EINVAL;
				break;

			case PCIDRV_16BITS:   
				/* translate phys. addr to virtual addr */
	vmptr_short = (short *)ioremap_nocache(pci_adr, arg.count*sizeof(short));
				vptr16 = vmptr_short;
				/* write shorts to the virtual addr */
				for (i = 0; i < arg.count; i ++) 
					writew( ((short *)(dma_buf))[i], vptr16++);
				/* unmap when no more needed */     
				iounmap(vmptr_short);
				break;     

			case PCIDRV_32BITS:    
				/* translate phys. addr to virtual addr */     
	vmptr_int = (int *)ioremap_nocache(pci_adr, arg.count*sizeof(int));
				vptr32 = vmptr_int;
				/* write ints to the virtual addr */
				for (i = 0; i < arg.count; i ++)
					writel( ((int *)(dma_buf))[i], vptr32++);
				/* unmap when no more needed */  
				iounmap(vmptr_int); 
				break;

			default:DBG(DBG_ERRORS, "bad size");
				return -EINVAL;
			}
		}

		kfree(dma_buf);
		
		break; /* end of case PCIDRV_IOC_TBUWR */

	case PCIDRV_IOC_CNFRD:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_CNFRD");

		/* Read out the PCI header in long (double word) access */ 

		for (i = 0; i < PCIDRV_HDR_SIZE; i+=4) {  
			pci_bus_read_config_dword(pcidrvgen_info->bus,
			                          pcidrvgen_info->dev_fct,
			                          i, (u_int *)&hdr[i]);
			}

		/* Convert addresses from kernel memory space to user one */ 
		if (copy_to_user((PCIDRV_hdr *)user_arg, &hdr, sizeof(PCIDRV_hdr)))
			{
			DBG(DBG_ERRORS, "copy_to_user() error");
			return -EFAULT; 
			}

		break; /* end of case PCIDRV_IOC_CNFRD */

	case PCIDRV_IOC_CNFWR:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_CNFWR");

		/* Convert addresses from user memory space to kernel one */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;  
			}

		/* Write to the PCI header */
		switch(arg.size) {

			case PCIDRV_8BITS :
	
			pci_bus_write_config_byte(pcidrvgen_info->bus,
			                          pcidrvgen_info->dev_fct,
			                          arg.offs,
			                          arg.data);
			break;

			case PCIDRV_16BITS :
			
			pci_bus_write_config_word(pcidrvgen_info->bus,
			                          pcidrvgen_info->dev_fct,
			                          arg.offs,
			                          arg.data);
			break;

			case PCIDRV_32BITS :
			
			pci_bus_write_config_dword(pcidrvgen_info->bus,
			                           pcidrvgen_info->dev_fct,
			                           arg.offs,
			                           arg.data);
			break;

			default: break;
			}

		break; /* end of case PCIDRV_IOC_CNFWR */

	case PCIDRV_IOC_DMARD: /* DMA Read via S5933 Fifo's (8x32-bits) */
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_DMARD");
        
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;
			}

		if (arg.data == PCIDRV_SYS_DMA) {
			dma_buf = (void *)kmalloc(arg.size, GFP_DMA);
			memcpy(dma_buf, (void *)arg.base, arg.size);
			}

		pci_adr = pcidrvgen_info->badr[0];

		/* Disable Read & Write transfer */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat & ~0x00004400 , pci_adr + AMCC_OP_REG_MCSR); 

		/* Reset AMCC S5933 internal FIFO flags */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat | 0x06000000, pci_adr + AMCC_OP_REG_MCSR); 

		/* Define FIFO management scheme */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat & ~0x00002200, pci_adr + AMCC_OP_REG_MCSR);

		/* Define FIFO priority scheme */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);  
		outl(pci_dat & ~0x00000100, pci_adr + AMCC_OP_REG_MCSR);    
		outl(pci_dat | 0x00001000, pci_adr + AMCC_OP_REG_MCSR);    

		/* Define transfer source address */
		if (arg.data == PCIDRV_SYS_DMA)
			outl(virt_to_phys((void *)dma_buf), pci_adr + AMCC_OP_REG_MRAR);
		else outl(arg.base, pci_adr + AMCC_OP_REG_MRAR);

		/* Define transfer byte counts */
		outl(arg.size, pci_adr + AMCC_OP_REG_MRTC);

		/* Enable Read transfer */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat | 0x00004000 , pci_adr + AMCC_OP_REG_MCSR); 

		/* Wait for End of Transfer */
		time_out = 10;
		do {
			udelay(10);
			time_out --;
			pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		} while (time_out && !(pci_dat & 0x00000040));

		kfree(dma_buf);

		break; /* end of case PCIDRV_IOC_DMARD */

	case PCIDRV_IOC_DMAWR: /* DMA Write via S5933 Fifo's (8x32-bits) */
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_DMAWR");
        
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;
			}

		pci_adr = pcidrvgen_info->badr[0];

		/* Disable Write & Read transfer */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat & ~0x00004400 , pci_adr + AMCC_OP_REG_MCSR); 

		/* Reset AMCC S5933 internal FIFO flags */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat | 0x06000000, pci_adr + AMCC_OP_REG_MCSR); 

		/* Define FIFO management scheme */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat & ~0x00002200, pci_adr + AMCC_OP_REG_MCSR);

		/* Define FIFO priority scheme */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);  
		outl(pci_dat & ~0x00001000, pci_adr + AMCC_OP_REG_MCSR);    
		outl(pci_dat | 0x00000100, pci_adr + AMCC_OP_REG_MCSR);    

		/* Define transfer target address */
		if (arg.data == PCIDRV_SYS_DMA) {
			dma_buf = (void *)kmalloc(arg.size, GFP_DMA);
			memset(dma_buf, 0, arg.size);
			outl(virt_to_phys((void *)dma_buf), pci_adr + AMCC_OP_REG_MWAR);
			}
		else
			outl(arg.base, pci_adr + AMCC_OP_REG_MWAR);

		/* Define transfer byte counts */
		outl(arg.size, pci_adr + AMCC_OP_REG_MWTC);

		/* Enable Write transfer */
		pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		outl(pci_dat | 0x00000400 , pci_adr + AMCC_OP_REG_MCSR); 

		/* Wait for End of Transfer */
		time_out = 10;
		do {
			udelay(10);
			time_out --;
			pci_dat = inl(pci_adr + AMCC_OP_REG_MCSR);
		} while (time_out && !(pci_dat & 0x00000080));

		/* Put DMA buffer from kernel memory space to user one */
		memcpy((void *)arg.base, dma_buf, arg.size);

		if (copy_to_user((PCIDRV_arg *)user_arg, &arg, SIZE_ARG))
			{
			DBG(DBG_ERRORS, "copy_to_user() error");
			return -EFAULT;
			}

		kfree(dma_buf);

		break; /* end of case PCIDRV_IOC_DMAWR */

        case PCIDRV_IOC_DMABM:  /* DMA Bus Mastering */
        /********************/

                DBG(DBG_IOCTLS, "PCIDRV_IOC_DMA (Add-On Bus Mastering)");

                if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
                        {
                        DBG(DBG_ERRORS, "copy_from_user() error");
                        return -EFAULT;
                        }

                /* pci_adr = pcidrvgen_info->badr[1]; */

                /* 1rst step */
                /* Allocate & Initialize Transfer target address */
                if (arg.data == DMA_INIT) 
		{
                	dma_buf_size = arg.size*arg.count;
                	DBG(DBG_INFOS, "kmalloc DMA buffer: %dB",
                                 dma_buf_size);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,25)
                	DBG(DBG_INFOS, "kmalloc max size  : %dKB",
                                 (int)(KMALLOC_MAX_SIZE/1024));
#endif
                	dma_buf = (void *)kmalloc(dma_buf_size, GFP_DMA);
                        if(dma_buf == NULL)
                        {
                          DBG(DBG_ERRORS, "kmalloc(%d) failed",dma_buf_size);
			  return -ENOMEM;
                        }
                	DBG(DBG_INFOS, "clear DMA buffer (%x)", (int)(dma_buf));
                	memset(dma_buf, 0, dma_buf_size);
                	arg.adbuf = (u_int *)virt_to_phys((void *)dma_buf);
                	DBG(DBG_INFOS, "return DMA buffer address (%08x)", 
				(int)(arg.adbuf)); 
/* outl(virt_to_phys((void *)dma_buf), pcidrvgen_info->badr[1] + 0x14); */
                }

                /* 2nd step */
                /* Put DMA buffer from kernel memory space to user one */
                /* memcpy((void *)arg.base, dma_buf, arg.size); */
                if (arg.data == DMA_READ) 
		{
                        user_buf_size = arg.size*arg.count;
                        if(user_buf_size > dma_buf_size)
                        {
                          DBG(DBG_ERRORS, "user buffer too large");
                          user_buf_size = dma_buf_size;
                        }
                	DBG(DBG_INFOS, "copy DMA buffer to user: %dB @ %08x",
                                user_buf_size,
                                (int)(arg.adbuf));
                	memcpy((u_int *)arg.adbuf, dma_buf, user_buf_size);
                	kfree(dma_buf);
                        dma_buf_size = 0;
                }

                if (copy_to_user((PCIDRV_arg *)user_arg, &arg, SIZE_ARG))
		{
                        DBG(DBG_ERRORS, "copy_to_user() error");
                        return -EFAULT;
		}

                DBG(DBG_IOCTLS, "exit PCIDRV_IOC_DMABM");
                break; /* end of case PCIDRV_IOC_DMABM */




        case PCIDRV_IOC_DMATW:  /* DMA Bus Mastering test write*/
	/********************/
                DBG(DBG_IOCTLS, "PCIDRV_IOC_DMATW (test writing DMA buffer)");

                if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
                {
                 DBG(DBG_ERRORS, "copy_from_user() error");
                 return -EFAULT;
                }

                if(dma_buf_size == 0)
                {
                 DBG(DBG_ERRORS, "No DMA buffer allocated, giving up");
                 return -EFAULT;
                }

                n = dma_buf_size;
                ptr_uchar = (char *)dma_buf;
                for(i=0; i<n; i++)
                 ptr_uchar[i] = (i & 0xff);
                DBG(DBG_INFOS, "Bytes of DMA buffer writen: %d @ %06d",
                 n, 0);


                DBG(DBG_IOCTLS, "exit PCIDRV_IOC_DMATW");
                break; /* end of case PCIDRV_IOC_DMATW */





	case PCIDRV_IOC_DEBUG:
	/********************/
	
		DBG(DBG_IOCTLS, "PCIDRV_IOC_DEBUG");

		/* Convert addresses from user memory space to kernel one */
		if (copy_from_user(&arg, (PCIDRV_arg *)user_arg, SIZE_ARG))
		{
			DBG(DBG_ERRORS, "copy_from_user() error");
			return -EFAULT;
		}                 
		
		/* Change the debug level for printing our debug messages */
		pcidrv_dbg = arg.data;  
		DBG(DBG_INFOS, "Debug = %1d", pcidrv_dbg);

		break;

	default:
		DBG(DBG_ERRORS, "unknown IOCTL(2) command");
		return -EINVAL;	

	} /* end of switch() */

	DBG(DBG_FUNCS, "ioctl() - exit");
	return ret;
}








/*------------------------------------------------------------------------------
 * Function:    set_ptr_priv_data()
 *
 * Description: This function returns a pointer on the private data structure
 *              (PCIDRVGEN_private)pcidrvgen_info according to a Minor number.
 *              This Minor number is the same as the variable `slot'.
 *              Just remind that this chain of structures has been allocated 
 *              for every PCI devices during init_module() execution 
 *              (cf initialization of `pcidrvgen_info_ptr' pointer). 
 *
 *----------------------------------------------------------------------------*/

static PCIDRVGEN_private *set_ptr_priv_data(unsigned int slot)
{
	PCIDRVGEN_private *pcidrvgen_info;

	pcidrvgen_info = pcidrvgen_info_ptr; /* set pointer on 1rst structure */

	/* Pass across the structures list to the jack-pot */
	while ((pcidrvgen_info) && (pcidrvgen_info->slot != slot))
		pcidrvgen_info = pcidrvgen_info->next;

	return(pcidrvgen_info);
}
