
/* ICV196 board registers */

#define   CLEAR          0x0

#define	  GR01_CH00_07   0x3
#define   GR02_CH08_15   0x2 
#define   GR03_CH16_23   0x5
#define   GR04_CH24_31   0x4
#define   GR05_CH32_39   0x7
#define   GR06_CH40_47   0x6
#define   GR07_CH48_55   0x9
#define   GR08_CH56_63   0x8
#define   GR09_CH64_71   0xB
#define   GR10_CH72_79   0xA
#define   GR11_CH80_87   0xD
#define   GR12_CH88_95   0xC

#define   DIR_G1_G8      0xF
#define   DIR_G9_12      0xE
#define   DIR_G1_G12     0xE

#define   ALL_GROUPS_AS_OUTPUT	0xFFF
