
/*+*****************************************************************************

 File       : EXT_VISU.C      
 Project    : Test program environment for PCI
 Description: Misc. functions to deal with screen & keyboard in a friendly way.
 Author(s)  : Ph. Chappelet

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 Include the header files
 */
 #if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI /* Not defined NIVISA_PXI , the whole file is ignored on WIN2000 **/ 

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

/*
 Include Specific Header files
 */

/* To retrieve Terminal input into TERMINFO database , type the Unix command :
             infocmp dtterm (or infocmp vt100)
   To have code meanings , type the Unix command :
             man 5 terminfo 
   For modes LINUX, DTTERM & VT100, we may assume that lines = 24 & cols = 80 
   
   Graphic char available : a,f,g,j,k,l,m,n,o,...,z, {, |, }, ~    */

#define	XCOL	80
#define XLIN	24


     
/**/
void Get_Term_Attr(void)
/*+*****************************************************************************
 Purpose     : Get the device Attributes Terminal.
 Description : WARNING : Uses directly the VT100 capabilities.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{	
	printf("%c%c%c", 0x1B, '[', 'c');	/* DA : device attributes */
	fflush(stdout);
	/* term responds with "ESC [ ? ; 0 c" */ 
}

/**/
void Set_Graphic_Mode(void)
/*+*****************************************************************************
 Purpose     : Turn the Special Graphic characters ON (code enacs).
 Description : WARNING : Uses directly the VT100 capabilities.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{	
	printf("%c%c%c", 0x1B, '(', '0');	/* Enter Graphic mode */
	/*** printf("%c%c%c", 0x1B, ')', '0');	Enter Graphic mode ???? */
	fflush(stdout); 
}


/**/
void Set_ASCII_Mode(void)
/*+*****************************************************************************
 Purpose     : Turn the Special Graphic characters OFF.
 Description : WARNING : Uses directly the VT100 capabilities.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{	
	printf("%c%c%c", 0x1B, '(', 'B');	/* Reset to ASCII mode */
	fflush(stdout); 
}


/**/
void Move_Cursor(int row, int column)
/*+*****************************************************************************
 Purpose     : Move cursor to the requested position (code cup/cm).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%d%c%d%c", 0x1B, '[', row, ';', column, 'H');
	fflush(stdout);
	/* usleep(5000); wait for 5 ms */
}


/**/
void Home_Cursor(void)
/*+*****************************************************************************
 Purpose     : Set cursor at Home position (code home/ho).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c", 0x1B, '[', 'H');
	fflush(stdout); 	
}


/**/
void Clr_EOL(void)
/*+*****************************************************************************
 Purpose     : Clear to Enf Of Line (code el/ce).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c", 0x1B, '[', 'K');
	fflush(stdout); 	
}


/**/
void Clr_EOS(void)
/*+*****************************************************************************
 Purpose     : Cleat to End Of Screen (code ed/cd).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c", 0x1B, '[', 'J');
	fflush(stdout); 	
}

/**/
int Draw_Border(int column, int line, int width, int height)
/*+*****************************************************************************
 Purpose     : Draws a box.
 Description : WARNING : Uses directly the VT100 capabilities.
               (height-2) lines are available inside the box.
 Arg(s) In   : column = column offset [1..80]
               line   = line   offset [1..24]
         
	       width  = [1..80]
	       height = [1..24]
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	int i;
	
	if ( (line + height) > 25 )
		return(-1);
	if ( (column + width) > 81 )
		return(-1);
		
	Set_Graphic_Mode();
	
	/* Four corners coordinates : ( 1,1) ; (1,80) ; (24, 1) ; (24,80) */
	
	/* draw TOP border line */
		
	Move_Cursor(line, column);
	printf("%c", 'l');	/* upper left corner */
	fflush(stdout);
	
	for (i = 1; i <= width-2; i++) {
		printf("%c", 'q');	/* horizontal line */
		fflush(stdout);
		}
		
	printf("%c", 'k');	/* upper right corner */
	fflush(stdout);
	
	/* draw EDGE border lines */
	
	for (i = 1; i <= height-2; i ++) { 
		Move_Cursor(line+i,column);		
		printf("%c", 'x');	/* vertical line */
		fflush(stdout);
		Move_Cursor(line+i,column+width-1);		
		printf("%c", 'x');	/* vertical line */
		fflush(stdout);
		}
	
	/* draw BOTTOM border line */	
		
	Move_Cursor(line+height-1, column);	
	printf("%c", 'm');	/* lower left corner */
	fflush(stdout);
	
	for (i = 1; i <= width-2; i++) {
		printf("%c", 'q');	/* horizontal line */
		fflush(stdout);
		}
		
	printf("%c", 'j');	/* lower right corner */
	fflush(stdout);
	
	Set_ASCII_Mode();
	
	return(0);
}


/**/
int Draw_Frame(int column, int line, int width, int height)
/*+*****************************************************************************
 Purpose     : Draws a box.
 Description : WARNING : Uses directly the VT100 capabilities.
               (height-2) lines are available inside the box.
 Arg(s) In   : column = column offset [1..80]
               line   = line   offset [1..24]
         
	       width  = [1..80]
	       height = [1..24]
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	int i;
	
	Draw_Border(column, line, width, height);
	
	Set_Graphic_Mode();

	/* draw Header line */
	
	Move_Cursor(line+2, column);
	printf("%c", 't');	/* upper left corner */
	fflush(stdout);
	
	for (i = 1; i <= width-2; i++) {
		printf("%c", 'q');	/* horizontal line */
		fflush(stdout);
		}
		
	printf("%c", 'u');	/* upper right corner */
	fflush(stdout);
	
	/* draw Vertical Middle line */
	
	Move_Cursor(line+2, (column+width)/2);	
	printf("%c", 'w');	/* Top "T" */
	fflush(stdout);
	
	for (i = 3; i <= height-2; i ++) { 
		Move_Cursor(line+i, (column+width)/2);		
		printf("%c", 'x');	/* vertical line */
		fflush(stdout);
		}

	Move_Cursor(line+height-1, (column+width)/2);	
	printf("%c", 'v');	/* Bottom "T" */
	fflush(stdout);
	
	
	
	Set_ASCII_Mode();
		
	return(0);
}

/* Origin is the upper left point set as (1,1) : 1rst line, 1rst column */
/* Syntax : Draw_Border(line, column, width, height) */

/**
Clear_Screen();
Draw_Border( 1,1, 80,10);
printf("\n12345678901234567890123456789012345678901234567890123456789012345678901234567890\n");
printf("0        1         2         3         4         5         6         7         8\n");         
**/

#endif /* Not defined NIVISA_PXI , the whole file is ignored on WIN2000 **/
