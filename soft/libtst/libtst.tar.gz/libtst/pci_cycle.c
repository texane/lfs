
/*+*****************************************************************************

 File       : PCI_CYCLE.C      
 Project    : Test program environment for PCI.
 Description: 
 Author(s)  : Ph. Chappelet

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 Include the header files
 For Windows2000 NI-VISA platform, visa headers are needed
 as well as specific in-house headers.
 */

#if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI
	#include <unistd.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <signal.h>
	#include <string.h>
	#include <getopt.h> 
	#include <termios.h>
	#include <sys/file.h>
	#include <sys/ioctl.h>
	#include <sys/utsname.h>
	#include <linux/pci.h>

	/* Include Specific Header files */
#if 0 /* was  */
	#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
	#include "/segfs/linux/drv/pci/V1.6/amcc.h"
	#include "../../../defs/pci_env_tst.h"
#else /* is */
	#include "pcidrvgen.h"
	#include "amcc.h"
	#include "defs/pci_env_tst.h"
#endif
#endif

#if defined NIVISA_PXI
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include "wdc_defs.h"
#include "utils.h"
#include "status_strings.h"
#include "C:\WinDriver\samples\shared\pci_regs.h"
#include "pcidrvgen.h"
#include "amcc.h"
#include "pci_env_tst.h"

//extern ViSession defaultRM ;
//extern ViSession visa_instr ;
extern WDC_DEVICE_HANDLE instr ;
extern DWORD EsrfManufId ;
extern CodeName EsrfModelsCodes[] ;
extern Keyboard_Input ;
#endif

/*
 Definition of External functions & Global variables
 */

extern void Print_Msg(u_char code, char *msg, u_int tempo);

/* 
 Declaration of functions & variables 
 */

int Bus_Master(u_int, u_int, u_int, u_int *);

int Read_PCI(u_int, u_int, u_int, u_int *);
int Write_PCI(u_int, u_int, u_int, u_int);

int Rd_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);
int Wr_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);


/**/
int Bus_Master(u_int mode, u_int size, u_int count, u_int *bdma)
/*+*****************************************************************************
 Purpose     : Bus Mastering operation (Add-ON initiated).
 
               For Windows2000 NI-VISA platform, built-in functions
               exist for each data size so based on the size parameter
               the right NI-VISA function will be used.
               The same for register base addresses, a mapping will be made from
               the badr argin to the NI-VISA address.
               
 Description : function ioctl(PCIDRV_IOC_DMABM) in driver PciDrvGen.
 Arg(s) In   : mode  = Allocate (DMA_INIT) or ReadBack (DMA_READ) kernel buffer.
               count = number of data to be transferred.
               size  = 8, 16 or 32 bits data type (PCIDRV_[8/16/32]BITS).
	       bdma  = physical address (given by kernel) where to start the 
	               DMA transfert when arg. mode = DMA_INIT (1rst step), 
					OR
		       pointer where to copy the DMA kernel buffer towards
		       user'space when arg. mode = DMA_READ (2nd step).
 Arg(s) Out  : bdma  = DMA phys. addr when mode = DMA_INIT.
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined( NIVISA_PXI )
	PCIDRV_arg arg;

        arg.data = mode;
        arg.size = size;
        arg.count = count;
    	if (mode == DMA_READ) 
		arg.adbuf = bdma;

        if ( ioctl(FD, PCIDRV_IOC_DMABM, &arg) == 0 ) {
		/* get back to user's space the kernel buffer address 
		used to store data for DMA transfert from Add-On to PCI bus */
		if (mode == DMA_INIT)
			*bdma = (u_int)arg.adbuf;
		return(0);
        } else {
		Print_Msg(ERROR, "on Bus Mastering operation.", -1);
		perror("PCIDRVGEN ioctl(PCIDRV_IOC_DMABM) ");
            return(-1);
        }
#endif
}


int Read_PCI(u_int badr, u_int offs, u_int size, u_int *data)
/*+*****************************************************************************
 Purpose     : Read a SINGLE PCI byte, word or long.
 
               For Windows2000 NI-VISA platform, built-in functions
               exist for each data size so based on the size parameter
               the right NI-VISA function will be used.
               The same for register base addresses, a mapping will be made from
               the badr argin to the NI-VISA address.
               
 Description : function ioctl(PCIDRV_IOC_REGRD) in driver PciDrvGen.
 Arg(s) In   : badr = Base Address register (BADR0 -> BADR5 = [0,..,5])
               offs = Offset register within badr.
               size = 8, 16 or 32 bits access (PCIDRV_[8/16/32]BITS).
	       data = pointer where to save the read value.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined( NIVISA_PXI )
	PCIDRV_arg arg;

        arg.base = badr;
        arg.offs = offs;
        arg.size = size;

        if ( ioctl(FD, PCIDRV_IOC_REGRD, &arg) == 0 ) {
			*data = arg.data;
			return(0);
        } else {
			Print_Msg(ERROR, "on Single reading from PCI bus.", -1);
			perror("PCIDRVGEN ioctl(PCIDRV_IOC_REGRD) ");
            return(-1);
        }
#endif

#if defined( NIVISA_PXI )
DWORD status =0;
BYTE val8 = 0;
WORD val16 = 0 ;
UINT32 val32 = 0 ;

extern WDC_DEVICE_HANDLE instr ;

	if( size == PCIDRV_8BITS ) {
		 status = WDC_ReadAddr8( instr,(DWORD)badr,
		 				(DWORD)offs, &val8);
		 if(status != WD_STATUS_SUCCESS ) {
		 	printf("Error WDC_ReadAddr8(%s) \n", Stat2Str(status) ); 
		 	return(-1);
		 } else {
		 	*data = (u_int)val8 ;
		 }
	} else if ( size == PCIDRV_16BITS ) {
		 status = WDC_ReadAddr16( instr,(DWORD)badr,
		 				(DWORD)offs, &val16);
		 if(status != WD_STATUS_SUCCESS ){
		 	printf("Error WDC_ReadAddr16(%s) \n", Stat2Str(status) );
		 	return(-1);
		 } else {
		 	*data = (u_int)val16 ;
		 }
	} else if ( size == PCIDRV_32BITS ) {
		 status = WDC_ReadAddr32( instr,(DWORD)badr,
		 				(DWORD)offs, &val32);
		  
		 if(status != WD_STATUS_SUCCESS ){
		 	printf("Error WDC_ReadAddr32(%s) \n", Stat2Str(status) );
		 	return(-1);
		 } else {
		 	*data = (u_int)val32 ;
		 }
	} else {
		printf("Error in requested data size !!\n");
		return (-1);
	}
	
return(0);
#endif
}


/**/
int Write_PCI(u_int badr, u_int offs, u_int size, u_int data)
/*+*****************************************************************************
 Purpose     : Write a SINGLE PCI byte, word or long.
 
 
               For Windows2000 NI-VISA platform, built-in functions
               exist for each data size so based on the size parameter
               the right NI-VISA function will be used.
               The same for registers base addresses, a mapping will be made from
               the badr argin to the NI-VISA address.
               
 Description : function ioctl(PCIDRV_IOC_REGWR) in driver PciDrvGen.
 Arg(s) In   : badr = Base Address register (BADR0 -> BADR5 = [0,..,5])
               offs = Offset register within badr.
	       size = 8, 16 or 32 bits access (PCIDRV_[8/16/32]BITS).
	       data = value to write.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined( NIVISA_PXI ) 
	PCIDRV_arg arg;

        arg.base = badr;
        arg.offs = offs;
        arg.size = size;
        arg.data = data;

        if ( ioctl(FD, PCIDRV_IOC_REGWR, &arg) == 0 ) 
			return(0);
		else {
			Print_Msg(ERROR, "on Single writing to PCI bus.", -1);
			perror("PCIDRVGEN ioctl(PCIDRV_IOC_REGWR) ");
            return(-1);
        }
#endif

#if defined( NIVISA_PXI )
DWORD status =0;
BYTE val8 = 0;
WORD val16 = 0 ;
UINT32 val32 = 0 ;

extern WDC_DEVICE_HANDLE instr ;

	if( size == PCIDRV_8BITS ) {
		 val8 = (BYTE)data ;
		 status = WDC_WriteAddr8(instr,(DWORD)badr,
		 				(DWORD)offs, val8);
		 if(status != WD_STATUS_SUCCESS ){
			printf("Error WDC_WriteAddr8(%s) \n", Stat2Str(status) );
		 	return(-1);
		 }
	} else if ( size == PCIDRV_16BITS ) {
		 val16 = (WORD)data ;
		 status = WDC_WriteAddr16(instr,(DWORD)badr,
		 				(DWORD)offs, val16);
		 if(status != WD_STATUS_SUCCESS ){
			printf("Error WDC_WriteAddr16(%s) \n", Stat2Str(status) );
		 	return(-1);
		 }
	} else if ( size == PCIDRV_32BITS ) {
		  val32 = (UINT32)data ;
		  status = WDC_WriteAddr32(instr,(DWORD)badr,
		 				(DWORD)offs, val32);
		 if(status != WD_STATUS_SUCCESS ){
			printf("Error WDC_WriteAddr32(%s) \n", Stat2Str(status) );
		 	return(-1);
		 } 
	} else {
		printf("Error in requested data size !!\n");
		return (-1);
	}	

return(0);
#endif
}

/**/
int Rd_Burst_PCI(u_int badr, u_int offs, u_int size, u_int count, u_int *bdma)
/*+*****************************************************************************
 Purpose     : Read PCI bytes, words or longs in burst cycles.
 Description : function ioctl(PCIDRV_IOC_TBURD) in driver PciDrvGen.
 Arg(s) In   : badr = Base Address register (BADR0 -> BADR5 = [0,..,5])
               offs = Offset register from badr.
	       size = 8, 16 or 32 bits access (PCIDRV_[8/16/32]BITS).
	       count= size of burst.
	       bdma = pointer to the buffer to fill with read data.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined( NIVISA_PXI ) 
	PCIDRV_arg arg;
	
        arg.base  = badr;
        arg.offs  = offs;
        arg.size  = size;
	arg.count = count;
	arg.adbuf = bdma;	
	
        if ( ioctl(FD, PCIDRV_IOC_TBURD, &arg) == 0 ) {
		return(0);
		}
	else {
		Print_Msg(ERROR, "on BURST reading from PCI bus.", -1);
		perror("PCIDRVGEN ioctl(PCIDRV_IOC_TBURD) ");
                return(-1);
                }
#endif

#if defined( NIVISA_PXI )
return(0);
#endif
}

/**/
int Wr_Burst_PCI(u_int badr, u_int offs, u_int size, u_int count, u_int *bdma)
/*+*****************************************************************************
 Purpose     : Write PCI bytes, words or longs in burst cycles.
 Description : function ioctl(PCIDRV_IOC_TBUWR) in driver PciDrvGen.
 Arg(s) In   : badr = Base Address register (BADR0 -> BADR5 = [0,..,5])
               offs = Offset register from badr.
	       size = 8, 16 or 32 bits access (PCIDRV_[8/16/32]BITS).
	       count= size of burst.
	       bdma = pointer to the buffer containing the data to write.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined( NIVISA_PXI ) 
	PCIDRV_arg arg;
			
        arg.base  = badr;	
        arg.offs  = offs;
        arg.size  = size;
	arg.count = count;
	arg.adbuf = bdma;
		
        if ( ioctl(FD, PCIDRV_IOC_TBUWR, &arg) == 0 ) 
		return(0);
	else {
		Print_Msg(ERROR, "on BURST writing to PCI bus.", -1);
		perror("PCIDRVGEN ioctl(PCIDRV_IOC_TBUWR) ");
                return(-1);
                }
#endif

#if defined( NIVISA_PXI )
return(0);
#endif
}


