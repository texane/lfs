
/*------------------------------------------------------------------------------
 * File:         pci_env_tst.h
 * Project:      PCI Generic Device Drivers
 * Description:  A standard utility to perform basic PCI access.
 * Author(s):    Philippe Chappelet
 * Original:     December 1999
 *
 * $Revision: 1.1 $
 *
 *----------------------------------------------------------------------------*/

#ifndef _PCI_ENV_TST_H
#define _PCI_ENV_TST_H

#if !defined NIVISA_PXI /** Linux is not W2000 **/

#define UNIX_PATH		"/segfs/digi/"

#define DEVICE_CONF    "/dev/pcidrvgen_conf"
#define DEVICE_NAME    "/dev/pcidrvgen"
#define NOT_OPEN       "NO DEVICE CHOOSEN"
#define FD_NOT_OPEN    -2  

#define TRUE		1
#define FALSE		0

#undef  BADR0
#define BADR0		0
#undef  BADR1
#define BADR1		1
#undef  BADR2
#define BADR2		2
#undef  BADR3
#define BADR3		3
#undef  BADR4
#define BADR4		4
#undef  BADR5
#define BADR5		5
#endif /* Not defined NIVISA_PXI **/  

#define VERBOSE		1
#define MUTE		0

#define DEFAULT_PLOT_FILE	"c111"
#define NVRAM_MAX_SIZE  0x800
#define READ       	1
#define WRITE		0

int opt_dbg,		/* debugging message level for the driver PCIDRVGEN */
	usr_did,		/* user DID specified in main() command line */
    chip_AMCC,		/* set TRUE when PCI interface = AMCC S593x */
    Keyboard_Input, /* set TRUE when <CTRL-C> detected on keyboard */
    FD;				/* LINUX File Descriptor of device selected */

unsigned int PCI_Hdr_Adrs[6],
             PCI_Hdr_Size[6],
             PCI_Hdr_Area[6];

struct _PCITST_nvr {
	unsigned short start;	/* NVram start  address to access */
	unsigned short stop;	/* NVram stop   address to access */
	char file_src[80];		/* name of file to download into NVram */
	char file_sav[80];		/* name of file to upload from NVram */
	};
	
typedef	struct _PCITST_nvr PCITST_nvr;


#if defined NIVISA_PXI

#define NOT_OPEN       "NO DEVICE CHOOSEN"
#define NIVISA_PATH		"C:\\VXIPNP\\ESRF\\"
#define FD_NOT_OPEN    -2 
#define NOT_ESRF_CARD  -3
#define TRUE		1
#define FALSE		0
#define	PCI_HEADER_TYPE	2

#undef  BADR0
#define BADR0		AD_PCI_BAR0 
#undef  BADR1
#define BADR1		AD_PCI_BAR1
#undef  BADR2
#define BADR2		AD_PCI_BAR2
#undef  BADR3
#define BADR3		AD_PCI_BAR3 
#undef  BADR4
#define BADR4		AD_PCI_BAR4
#undef  BADR5
#define BADR5		AD_PCI_BAR5

typedef unsigned char		u_char;
typedef unsigned short		u_short;
typedef unsigned int		u_int;
typedef unsigned long		u_long;

static DWORD EsrfManufId = 0x10E8 ;

#define EsrfModelsNumber	8
typedef struct _CodeName {
				DWORD code ;
				char *name ;
				} CodeName ;
				
static CodeName EsrfModelsCodes[EsrfModelsNumber] = {
					0xEE08 , "C111" , 
					0xEE10 , "C208" , 
					0x8403 , "C412" ,
					0xEE14 , "C501" ,
					0xEE18 , "CFBUS" ,
					0xEE11 , "CPDU" ,
					0xEE1C , "IEFF" ,
					0xEE20 , "FIDL"
					} ;

WDC_DEVICE_HANDLE instr ;					
//ViSession visa_instr ;
//ViSession defaultRM;
int  Keyboard_Input ;

#endif /* NIVISA_PXI **/

#endif  /* _PCI_ENV_TST_H */   

