

/*+*****************************************************************************

 File       : PCI_ENV_TST.C      
 Project    : Test program environment for PCI
 Description: TEST_OPEN() & TEST_CLOSE() definitions.
 Author(s)  : Ph. Chappelet

 Copyright (c) 2002 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 Include the header files
 */
#if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/utsname.h>

#include <linux/pci.h>

/*
 Include Specific Header files
 */

#if 0 /* was */
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "../../../defs/pci_env_tst.h"
#else /* is */
#include "pcidrvgen.h"
#include "defs/pci_env_tst.h"
#endif
#endif

#if defined NIVISA_PXI
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include "wdc_defs.h"
#include "utils.h"
#include "status_strings.h"
//#include "C:\WinDriver\samples\shared\pci_regs.h"
#include "pci_regs.h"
#include "tst_lib.h"
#include "pcidrvgen.h"
#include "amcc.h"
#include "pci_env_tst.h"

//extern ViSession defaultRM ;
//extern ViSession visa_instr ;
extern WDC_DEVICE_HANDLE instr ;
extern DWORD EsrfManufId ;
extern CodeName EsrfModelsCodes[] ;
extern Keyboard_Input ;

#endif
/*
 Definition of External functions & Global variables
 */

extern int Read_PCI_Config(PCIDRV_hdr *);
extern int Display_PCI_Header(PCIDRV_hdr, int);
extern int Dev_Info(u_short, u_short);

extern void Print_Msg(char code, char *msg, int tempo);
extern void Signal_Handler(int);
extern void Wait_and_See(char *), Set_Bold(void), Clr_Attr(void);

#if !defined NIVISA_PXI  // linux code

/**/
void TEST_OPEN(unsigned short did)
/*+*****************************************************************************
 Purpose     : Deals with all the LINUX & PCI worries.
 Description : in a few words, retrieve the user's board in the LINUX/PCI fog.
 Arg(s) In   : 0xFFFF or Device IDentifier (when specified by user)
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	char Line[80];
	int i, Match, par;

	struct utsname *info_sys;
	struct sigaction kbd;

	char device_desc[80];
	int minor_num = 0, FD_CONF;
	unsigned int *ptr;

	int PCI_devcount;
	
	PCIDRV_hdr hdr;
	PCIDRV_arg arg;
	PCIDRVGEN_private dev_arg;
/* 
 * Get information on the current Linux distributor	
 */
	/* cf file `/etc/SuSE-release' */
/*
 * Get name & informations on current Linux kernel
 */
 	Set_Bold();
	
 	info_sys = malloc(sizeof(struct utsname));
	if (uname(info_sys) != -1) {
		printf("\n\t%s %s %s %s %s\n", info_sys->sysname,  \
					       info_sys->nodename, \
					       info_sys->release,  \
					       info_sys->version,  \
					       info_sys->machine   );
		}
	free(info_sys);
	
	Clr_Attr();
/* 
 * Set up a signal handler for intercepting CTRL-C 
 */
	memset(&kbd, 0, sizeof(kbd));
	kbd.sa_handler = Signal_Handler;
	if (sigaction(SIGINT, &kbd, NULL)) {
		printf("\nWARNING Unable to set <Ctrl-C> intercept.\n");
		perror("Sigaction() system call ");
		}
/*
 * Set NO device descriptor for the driver as the default configuration
 */
	sprintf(device_desc, "%s", NOT_OPEN);
	FD = FD_NOT_OPEN;
/*
 * First of all, Open the PCI Configuration device descriptor (..._0)
 */
	FD_CONF = open (DEVICE_CONF, O_RDWR, 0x666); 
	if (FD_CONF == -1) {
		printf("\nERROR on opening %s\n", DEVICE_CONF);
		perror("PciDrvGen open() ");
		printf("Check the driver `pcidrvgen' is loaded in the kernel.\n\n");
		exit(0);
		}
/*
 * Set the debug level of the driver
 */
	arg.data = opt_dbg;
	if ( ioctl(FD_CONF, PCIDRV_IOC_DEBUG, &arg) != 0 ) {
		printf("\nERROR setting debug level on %s\n",DEVICE_CONF);
		perror("PciDrvGen ioctl(PCIDRV_IOC_DEBUG) ");
		sleep(2);
		}
/*
 * Scan all the PCI devices present in the LINUX system
 */
	if ((PCI_devcount = ioctl(FD_CONF, PCIDRV_IOC_DEVNB)) < 0) {
		printf("\nERROR on scanning PCI devs with %s\n", DEVICE_CONF);
		perror("PciDrvGen ioctl(PCIDRV_IOC_DEVNB) ");
		close(FD_CONF);
		exit(0);	
		}
/*
 * Display all the PCI devices present in the LINUX system
 */
	usr_did = did;	/* set global variable to did parameter */
	if (usr_did == 0xFFFF)
		printf("\nNumber of PCI devices : %d\n\n", PCI_devcount);

	for (i = 1; i <= PCI_devcount; i++) {

		dev_arg.slot = i;

		if (ioctl(FD_CONF, PCIDRV_IOC_SCAN, &dev_arg) < 0) {
			printf(" %2d - ERROR on reading PCI with %s\n", i, DEVICE_CONF);
			perror(" PciDrvGen ioctl(PCIDRV_IOC_SCAN) ");
			}
		else { /* check parameters returned by driver */
			
			if (usr_did != 0xFFFF) { /* search a specified DID */
				if ((dev_arg.vid == 0x10E8) && (dev_arg.did == usr_did)) {
					minor_num = dev_arg.slot;
					break;
					}
				}

			else { /* list all DID present */
				printf(" %2d - Vendor Id: $%04X  Device Id: $%04X - ",
				         i, dev_arg.vid, dev_arg.did);
				Dev_Info(dev_arg.vid, dev_arg.did); 
				}
			}
		} /* end of FOR (i ...) */
/* 
 * Found requested DID ?
 */
	if ( (usr_did != 0xFFFF) && (minor_num == 0)) {
		printf("\nSorry ! such DID $%04x (with VID $10E8 from AMCC) not detected on PCI bus.\n\n", usr_did);
		close(FD_CONF);
		exit(0);
		}
/*
 * Select one PCI device out of the list above
 */
	if (usr_did == 0xFFFF) { /* select one DID in the list */

		do {
			printf("\nSelect a PCI device number (0 to quit) : ");
			fflush(stdout);
			fgets(Line, sizeof(Line), stdin); 
			Match = sscanf(Line, "%d", &par);
		} while ( (Match <= 0) || (par < 0 || par > PCI_devcount) );

		if (par == 0) {
			close(FD_CONF);
			exit(0);
			}

		minor_num = par;
		}
/* 
 * Open a file descriptor on the selected PCI device
 */
	sprintf(device_desc, "%s%d", DEVICE_NAME, minor_num);
	FD = open (device_desc, O_RDWR, 0x666);
	printf("\nLinux Driver `PCIDRVGEN' : Device file = %s - File desc. = %d\n",
		        device_desc, FD);

	if (FD == -1) {
		printf("\nERROR on opening %s\n", device_desc);
		perror("PciDrvGen open() ");
		close(FD_CONF); 
		exit (0);
		}
/*
 * Retrieves BIOS config. parameters within LINUX environment
 */
	if (ioctl(FD, PCIDRV_IOC_INFRD, &dev_arg) < 0) {
		printf(" %2d - ERROR on reading PCI with %s\n", i, DEVICE_CONF);
		perror(" PciDrvGen ioctl(PCIDRV_IOC_INFRD) ");
		}
	else {
		for (i = 0; i <= 5; i ++) {
			PCI_Hdr_Size[i] = (unsigned int) dev_arg.size[i];
			PCI_Hdr_Area[i] = (unsigned int) dev_arg.iotype[i];
			}	
		}		
/* 
 * Retrieves BIOS config. parameters within the PCI header (Header type, ...)
 */
	if (Read_PCI_Config(&hdr) == -1) {
		Print_Msg(ERROR, "on read-back Config Space Header region", -1);
		close(FD_CONF);
		close(FD);
		exit(0); 
		}   
	else {
		ptr = (unsigned int *)&hdr;

		if ((*(ptr + (PCI_HEADER_TYPE>>2)) & 0x00010000) == 0) {
		
			if ((*ptr & 0xffff) == 0x10E8) 
				chip_AMCC = TRUE;
				
			PCI_Hdr_Adrs[0] = *(ptr + (PCI_BASE_ADDRESS_0>>2));
			if (PCI_Hdr_Area[0] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[0] &= 0xFFFFFFFE;
				 
			PCI_Hdr_Adrs[1] = *(ptr + (PCI_BASE_ADDRESS_1>>2));
			if (PCI_Hdr_Area[1] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[1] &= 0xFFFFFFFE;
			
			PCI_Hdr_Adrs[2] = *(ptr + (PCI_BASE_ADDRESS_2>>2));
			if (PCI_Hdr_Area[2] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[2] &= 0xFFFFFFFE;
			
			PCI_Hdr_Adrs[3] = *(ptr + (PCI_BASE_ADDRESS_3>>2));
			if (PCI_Hdr_Area[3] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[3] &= 0xFFFFFFFE;

			PCI_Hdr_Adrs[4] = *(ptr + (PCI_BASE_ADDRESS_4>>2));
			if (PCI_Hdr_Area[4] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[4] &= 0xFFFFFFFE;

			PCI_Hdr_Adrs[5] = *(ptr + (PCI_BASE_ADDRESS_5>>2));
			if (PCI_Hdr_Area[5] == PCI_BASE_ADDRESS_SPACE_IO)
				PCI_Hdr_Adrs[5] &= 0xFFFFFFFE;

			if (usr_did == 0xFFFF) {
				Display_PCI_Header(hdr, SHORT);
				Wait_and_See("strike <ENTER> to continue\n");
				}
			}
		else { /* Header type = 1 -> PCI/PCI bridge */
			Display_PCI_Header(hdr, LONG);
			printf("\nSORRY ! the program `PCYCLE' does NOT support access to PCI/PCI bridge.\n\n");
			close(FD_CONF);
			close(FD);
			exit(0);
			}
		}
/*
 * Close the PCI Configuration device descriptor (..._0)
 */		
	close(FD_CONF);
}


/**/
void TEST_CLOSE(void)
/*+*****************************************************************************
 Purpose     : Deals with all the LINUX & PCI worries.
 Description : tired ? don't worry, just close before leaving.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	close(FD);
}

#endif // Not NIVISA_PXI , linux code

#if defined NIVISA_PXI
////////////////////////////////////////////////////////////////////////////////
//
// Will display base addr, mem zize, mem type
//  for each mem segment of the given PCI opeened session
//
////////////////////////////////////////////////////////////////////////////////
DWORD ShowPxiMemories(WDC_DEVICE_HANDLE instr) {
 DWORD dwAddrSpace;
 TST_ADDR_SPACE_INFO addrSpaceInfo;
 
	DWORD dwNumAddrSpaces = TST_GetNumAddrSpaces( instr );
    for (dwAddrSpace = 0; dwAddrSpace < dwNumAddrSpaces; dwAddrSpace++)
    {
        BZERO(addrSpaceInfo);
        addrSpaceInfo.dwAddrSpace = dwAddrSpace;
        if (!TST_GetAddrSpaceInfo( instr , &addrSpaceInfo))
        {
         printf("SetAddrSpace: Error - Failed to get address space information: %s",
                  TST_GetLastErr());
            return -1 ;
        }
		printf("%ld. %-*s %-*s %s\n",
						dwAddrSpace + 1,
						MAX_NAME_DISPLAY, addrSpaceInfo.sName,
						MAX_TYPE - 1, addrSpaceInfo.sType,
						addrSpaceInfo.sDesc);
		//printf("\n");
	}
 
return (0) ;   
}


///////////////////////////////////////////////////////////////////////////////
void TEST_OPEN(unsigned short did)
/*+*****************************************************************************
 Purpose     : Deals with all the VISA & PCI worries.
 Description : in a few words, retrieve the user's board in the VISA/PCI fog.
 Arg(s) In   : 0xFFFF or Device IDentifier (when specified by user)
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
 DWORD status = WD_STATUS_SUCCESS ;
 DWORD i, dwNumDevices;
 WDC_PCI_SCAN_RESULT scanResult;
 WD_PCI_CARD_INFO deviceInfo;
	

	status = TST_LibInit();
    if (WD_STATUS_SUCCESS != status)
    {
        printf("TEST_OPEN(): Failed to initialize the TST library: %s",
            TST_GetLastErr());
    }
	BZERO(deviceInfo);
	BZERO(scanResult);
    status = WDC_PciScanDevices(TST_DEFAULT_VENDOR_ID, did , &scanResult);
    if (WD_STATUS_SUCCESS != status)
    {
        printf("DeviceFind: Failed scanning the PCI bus.\n"
            "Error: 0x%lx - %s\n", status, Stat2Str(status));
    }

    dwNumDevices = scanResult.dwNumDevices;
    if (!dwNumDevices)
    {
        printf("No matching device was found for search criteria "
            "(Vendor ID 0x%lX, Device ID 0x%lX)\n",
            TST_DEFAULT_VENDOR_ID, did );
    }

	for(i=0;i< (int)dwNumDevices;i++) {
		BZERO(instr) ; /** init WDC session at each turn in the loop **/
		BZERO(deviceInfo);
		deviceInfo.pciSlot =  scanResult.deviceSlot[i]; //*pSlot;
		status = WDC_PciGetDeviceInfo(&deviceInfo);
		if (WD_STATUS_SUCCESS != status)
		{
        printf( "WD_PciGetDeviceInfo: Failed retrieving the device's resources information.\n"
            "Error 0x%lx - %s\n", status, Stat2Str(status));
		}

		/* Open a handle to the device */
		instr = TST_DeviceOpen(&deviceInfo);
		if ( !instr )
		{
        printf("TST_DeviceOpen: Failed opening a handle to the device: %s",
            TST_GetLastErr());
		}
	} // end for 
   ShowPxiMemories( instr);
}

/**/
void TEST_CLOSE(void)
/*+*****************************************************************************
 Purpose     : Deals with all the VISA & PCI worries.
 Description : tired ? don't worry, just close before leaving.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	if (!TST_DeviceClose( instr ))
    {
        printf("DeviceClose: Failed closing TST device: %s",
            TST_GetLastErr());
    }
}
#endif // if defined NIVISA_PXI, not linux code

