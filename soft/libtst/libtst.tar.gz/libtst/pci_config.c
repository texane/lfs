
/*+*****************************************************************************

 File       : PCI_CONFIG.C      
 Project    : Basic Read/Write accesses to the PCI Configuration space.
 Description: Use the driver generic PCIDRVGEN (M.Perez/Ph. Chappelet)
 Author(s)  : Ph. Chappelet

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 Include General Header files
 */
#if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI 
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <ctype.h>

#include <sys/ioctl.h> 
#include <linux/pci.h>

/*
 Include Specific Header files
 */

#if 0 /* was */
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "../../../defs/pci_env_tst.h"
#else /* is */
#include "pcidrvgen.h"
#include "defs/pci_env_tst.h"
#endif

#endif

#if defined NIVISA_PXI
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include "wdc_defs.h"
#include "utils.h"
#include "status_strings.h"
#include "C:\WinDriver\samples\shared\pci_regs.h"
#include "pcidrvgen.h"
#include "amcc.h"
#include "pci_env_tst.h"

//extern ViSession defaultRM ;
//extern ViSession visa_instr ;
extern DWORD EsrfManufId ;
extern CodeName EsrfModelsCodes[] ;
extern Keyboard_Input ;
#endif
/*
 * Declaration of External functions & Global variables 
 */
 
extern void Print_Msg(u_char code, char *msg, u_int tempo);

/*
 * Declaration of Local functions & variables 
 */

int  Read_PCI_Config(PCIDRV_hdr *), Write_PCI_Config(PCIDRV_arg *);
void Set_PCI_Config(PCIDRV_arg *);   

void Display_PCI_Header(PCIDRV_hdr, int);
int  Dev_Info(u_short, u_short);
char *VID_str(char *), *DID_str(char *);

static char *PCI_hdr0_field_long[] = {
        "     Device ID     /     Vendor ID     ",
        "       Status      /      Command      ",
        "   Class Code (base:sub:prog I/F)  / Revision ID ",
        "  BIST  / Hdr type / Latency timer / Cache Line size",
        "                               #0      ",
        "                               #1      ",
        "         Base Address Register #2      ",
        "                               #3      ",
        "                               #4      ",
        "                               #5      ",
        "          Cardbus CIS Pointer          ",
        "   Subsystem ID    / Subsystem vendor ID",
        "        Expansion ROM Base Address     ",
        "               (reserved)              ",
        "               (reserved)              ",
        " Max_Lat / Min_Gnt / Int Pin / Int Line"
};





/**/
int Read_PCI_Config(PCIDRV_hdr *ptr_hdr)
/*+*****************************************************************************
 Purpose     : read PCI header (256 bytes).
 Description :
 Arg(s) In   :
 Arg(s) Out  :
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined NIVISA_PXI
	if ( ioctl(FD, PCIDRV_IOC_CNFRD, ptr_hdr) == 0 ) 
		return(0);
	else {
		Print_Msg(ERROR, "on reading PCI header", -1);
		perror(" PCIDRVGEN ioctl(PCIDRV_IOC_CNFRD)");
		return(-1); 
		}
#endif
#if defined NIVISA_PXI
	return(0);
#endif
}


/**/
int Write_PCI_Config(PCIDRV_arg *ptr_arg)
/*+*****************************************************************************
 Purpose     : write a byte/word/long into PCI header.
 Description :
 Arg(s) In   :
 Arg(s) Out  :
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#if !defined NIVISA_PXI    
	if ( ioctl(FD, PCIDRV_IOC_CNFWR, ptr_arg) == 0 ) 
		return(0);
	else {
		Print_Msg(ERROR, "on writing PCI header", 2);
		perror(" PCIDRVGEN ioctl(PCIDRV_IOC_CNFWR)");
		return(-1); 
		}
#endif
#if defined NIVISA_PXI
	return(0);
#endif
}


/**/
void Display_PCI_Header(PCIDRV_hdr ptr_hdr, int mode)
/*+*****************************************************************************
 Purpose     : displays PCI header contents on screen.
 Description :
 Arg(s) In   : a structure ptr_hdr to display contents.
               mode = SHORT (64 bytes) or LONG (256 bytes).
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
        register int i;
	unsigned int *p;  

        if (mode == LONG) { /* display entire Header (256 bytes) */
		p = (unsigned int *)ptr_hdr;
		printf("\n        3 2 1 0      $04      $08      $0C");
		printf("      $10      $14      $18      $1C"); 
		for (i = 0; i < PCIDRV_HDR_SIZE/4; i ++) {
			if (i%8 == 0) 
				printf("\n $%02X :", 4*i);
			printf(" %08x", *p++);
			}
		fflush(stdout);
		printf("\n");
		}
	else { /* display Config Space Header region (64 bytes) */
		p = (unsigned int *)ptr_hdr;
		if ((*(p + (PCI_HEADER_TYPE>>2)) & 0x00010000) == 0) {
			printf("\n        MsB ...... LsB\t\t\tDescription\n");
			printf("       ----------------\t\t\t-----------\n");
			for (i = 0; i < 64;i += 4) {
				printf("  $%02X : %02X  %02X  %02X  %02X : %s\n",
				          i, ptr_hdr[i+3], ptr_hdr[i+2],
                                          ptr_hdr[i+1], ptr_hdr[i+0],
        			          PCI_hdr0_field_long[i/4]);
				if (i == 12) printf("\n");
				}
			}
		else { /* Header type #1 -> PCI/PCI bridge */
			for (i = 0; i < 64;i += 4) {
				printf("  $%02X : %02X  %02X  %02X  %02X :\n",
				          i, ptr_hdr[i+3], ptr_hdr[i+2],
				          ptr_hdr[i+1], ptr_hdr[i+0]);
				}
			}
		}        
}


/**/
int Dev_Info(unsigned short vendor_id, unsigned short device_id)
/*+*****************************************************************************
 Purpose     : search & display human information about PCI device.
 Description : based on information retrieved in /usr/include/linux/pci_ids.h
 Arg(s) In   : vid = Vendor ID , did = Device ID
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
/* Vendor and card ID's in the file /usr/include/linux/pci_ids.h are represented
   according to the following fashion :
   		PCI_VENDOR_ID_manufacturer
		PCI_DEVICE_ID_manufacturer_product */

	char *status, id_line[80], def_key[80], id_string[80];
	int id_code, vid_match = FALSE, did_match = FALSE;
	FILE *fp_ids;

	if ( (fp_ids = fopen("/usr/include/linux/pci_ids.h", "r")) == NULL )
		return(-1);

	do {
		status = fgets(id_line, sizeof(id_line), fp_ids);
		sscanf(id_line,"%s %s %x", def_key, id_string, &id_code);
		if (strncmp(id_string, "PCI_VENDOR_ID_", 14) == 0) {
			if ((unsigned short)id_code == vendor_id) 
				vid_match = TRUE;
			}
	} while (status != NULL && !vid_match);

	if (vid_match) {

		printf("%-10s ", VID_str(id_string));
		fflush(stdout);

		do {
			status = fgets(id_line, sizeof(id_line), fp_ids); 
			sscanf(id_line,"%s %s %x",def_key, id_string, &id_code);
			if (strncmp(id_string, "PCI_DEVICE_ID_", 14) == 0) {
				if ((unsigned short)id_code == device_id) {
					did_match = TRUE;
					printf("%-20s\n", DID_str(id_string));
					}
				}
			else status = NULL;
		} while (status != NULL && !did_match);

		if (!did_match) 
			printf("(unknown)\n");
	}
	else printf("!(unknown)\n");

	fclose(fp_ids);

	return(0);
}


/**/
char *VID_str(char *id_str)
/*+*****************************************************************************
 Purpose     : retrieve the Vendor ID in a string.
 Description : cf file /usr/include/linux/pci_ids.h.
 Arg(s) In   : the string to scan.
 Arg(s) Out  : none
 Return(s)   : Vendor ID string.
*****************************************************************************-*/
{
	char *p;
	static char str[80];
	int i = 0;

	p = &id_str[14]; /* skip "PCI_DEVICE_ID_" token */

	do {
		str[i++] = *p++;
	} while (*p != '_');

	str[i] = '\0'; /* set end of string */

	return(str);
}


/**/
char *DID_str(char *id_str)
/*+*****************************************************************************
 Purpose     : retrieve the Device ID in a string.
 Description : cf file /usr/include/linux/pci_ids.h.
 Arg(s) In   : the string to scan.
 Arg(s) Out  : none
 Return(s)   : Device ID string.
*****************************************************************************-*/
{
	char *p;
	static char str[80];
	int i = 0;

	p = &id_str[14]; /* skip "PCI_DEVICE_ID_" token */

	do {
		str[i++] = *p++; /* skip VENDOR information */
	} while (*p != '_');

	i = 0;

	do {
		str[i++] = *++p;
	} while (*p != '\0');

	str[i] = '\0'; /* set end of string */

	return(str);
}


/**/
void Set_PCI_Config(PCIDRV_arg *ptr_arg)
/*+*****************************************************************************
 Purpose     : Modify PCI header fields according to user's request.
 Description :
 Arg(s) In   : 
 Arg(s) Out  :
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	
	unsigned char line[80], modify = TRUE;

	ptr_arg->base = 0; /* unused parameter in this case */

	printf("\nSelect an AMCC's S593x Configuration reg. to modify :\n");
	printf("\t- Status             (s)\n");
	printf("\t- Command            (c)\n");
	printf("\t- Latency Timer      (l)\n");
	printf("\t- Base address       (1..5)\n");
	printf("\t- Expansion ROM addr (e)\n"); 
	printf("\t- Interrupt line     (i)\n");
	printf("\nEnter your selection (q to quit) : ");
	fflush(stdout);

	do {
		fgets(line, sizeof(line), stdin); 
		line[0] = (u_char)tolower(line[0]);
	} while (line[0] != 's' && line[0] != 'c' && line[0] != 'l' 
	      && line[0] != '1' && line[0] != '2' && line[0] != '3'
	      && line[0] != '4' && line[0] != '5'
	      && line[0] != 'e' && line[0] != 'i'
	      && line[0] != 'q');

	switch(line[0]) {

		case 's' : /* Status register (16 bits) */
		           ptr_arg->offs = 0x6;
		           ptr_arg->size = PCIDRV_16BITS;
			   break;

		case 'c' : /* Command register (16 bits) */
		           ptr_arg->offs = 0x4;
		           ptr_arg->size = PCIDRV_16BITS;
			   break;

		case 'l' : /* Latency Timer register (8 bits) */
		           ptr_arg->offs = 0xD;
		           ptr_arg->size = PCIDRV_8BITS;
			   break;

		case 'e' : /* Expansion ROM Base address (32 bits) */
		           ptr_arg->offs = 0x30;
		           ptr_arg->size = PCIDRV_32BITS;
			   break;

		case 'i' : /* Interrupt Line (8 bits) */
		           ptr_arg->offs = 0x3C;
		           ptr_arg->size = PCIDRV_8BITS;
			   break;

		case '1' : 
		case '2' : 
		case '3' : 
		case '4' : 
		case '5' : /* Base Address register */ 
		           ptr_arg->offs = 0x10 + 4 * (line[0] - 0x31);
		           ptr_arg->size = PCIDRV_32BITS;
			   break;

		case 'q' :
		default  : modify = FALSE;
		           break;
		}

	if (modify == TRUE) {
		printf("Enter the new Configuration value (hexa) ? ");
		fflush(stdout);
		fgets(line, sizeof(line), stdin); 
		sscanf(line, "%x", &ptr_arg->data); 
		}
}

