

/*+*****************************************************************************

 File       : AMCC_NVRAM.C      
 Project    : Operations on line with the serial NVRam wired to an AMCC S593x.
 Description: Use the driver generic PCIDRVGEN (M.Perez/Ph.Chappelet)
 Author(s)  : Ph. Chappelet

 Revision   : 1.0 (10 Avril 2002) - Origine
			  1.1 (22 Octobre 2002) - Suppression du test sur le DID $4750
				  dans la fonction Load_File_NVram()

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 * Include the General Header files
 */

#if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI /** Linux **/
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

/*
 * Include Specific Header files
 */

#if 0 /* was */
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "/segfs/linux/drv/pci/V1.6/amcc.h"
#include "../../../defs/pci_env_tst.h"
#else
#include "pcidrvgen.h"
#include "amcc.h"
#include "defs/pci_env_tst.h"
#endif

#endif

#if defined NIVISA_PXI /** W2000 WIN_DRIVER **/

#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include "wdc_defs.h"
#include "utils.h"
#include "status_strings.h"
#include "C:\WinDriver\samples\shared\pci_regs.h"
#include "pcidrvgen.h"
#include "amcc.h"
#include "pci_env_tst.h"

//#include <windows.h>

#endif 

/*
 * Declaration of External functions
 */

extern int  Read_PCI(u_int, u_int, u_int, u_int *), 
            Write_PCI(u_int, u_int, u_int, u_int);
extern void Print_Msg(u_char, char *, u_int);

/* 
 * Declaration of Local functions & variables
 */

unsigned int nvd;	/* store the value read out from the chip NVram*/
 
int Read_AMCC_NVram(PCITST_nvr, unsigned char *);
int Store_File_NVram(PCITST_nvr, unsigned char *);

int Write_AMCC_NVram(PCITST_nvr, unsigned char *);
int Load_File_NVram(PCITST_nvr, unsigned char *);

int Display_AMCC_NVram(PCITST_nvr, unsigned char *);

int NVRAM_Cycle(char, unsigned short, unsigned char);




/**/
int Display_AMCC_NVram(PCITST_nvr ctrl, u_char *data)
/*+*****************************************************************************
 Purpose     : display on screen the array pointed by data.
 Description : max device = 24C16 (address range : 0x000 -> 0x7FF)
 Arg(s) In   : a structure ctrl of type PCITST_nvr.
               a pointer on the array data to display. 
	       (previously filled with Read_AMCC_NVram() function).
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	unsigned short addr;
				
	if (ctrl.start > ctrl.stop || ctrl.stop >= NVRAM_MAX_SIZE) {
		Print_Msg(ERROR, "on NVram addresses selection.", 1);
		return(-1);
		}	

	printf("\t\t       0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\n");
	printf("\t\t      -----------------------------------------------\n");

	for (addr = ctrl.start; addr <= ctrl.stop; addr ++) {
	
		if ((addr & 0x0F) == 0) {
			printf("\n\t@NVram $%03x : ", addr);
			fflush(stdout);
			}
		printf("%02x ", data[addr]);
		fflush(stdout);
		
		}
		
	printf("\n");
	
	return(0);
}

/**/
int Read_AMCC_NVram(PCITST_nvr ctrl, u_char *data)
/*+*****************************************************************************
 Purpose     : read the serial NVram contents of a PCI board with an AMCC.
 Description : max device = 24C16 (address range : 0x000 -> 0x7FF)
               fill the array data with the NVram contents.
 Arg(s) In   : a structure ctrl of type PCITST_nvr.
               a pointer on the array data to fill with NVram data.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	unsigned short addr;
		
	if (ctrl.start > ctrl.stop || ctrl.stop >= NVRAM_MAX_SIZE) {
		Print_Msg(ERROR, "on NVram addresses selection.", 1);
		return(-1);
		}
		
	for (addr = ctrl.start; addr <= ctrl.stop; addr++) { 

		if (NVRAM_Cycle(READ, addr, 0) < 0) {
			Print_Msg(ERROR, "on reading AMCC NVram", 1);
			return(-1); 
			}
		else /* saves the readout value */
			data[addr] = (u_char)nvd;
		}
	
	return(0);
}


/**/
int Store_File_NVram(PCITST_nvr ctrl, u_char *data)
/*+*****************************************************************************
 Purpose     : Save the serial NVram contents into a file on hard disk.
 Description : Save the array pointed by data into a file specified in ctrl.
 Arg(s) In   : a structure ctrl of type PCITST_nvr.
               a pointer on the array data to save.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	FILE *fp;
	unsigned short addr;

	if (ctrl.start > ctrl.stop || ctrl.stop >= NVRAM_MAX_SIZE) {
		Print_Msg(ERROR, "on NVram addresses selection.", 1);
		return(-1);
		}
		
	if ((fp = fopen(ctrl.file_sav, "w")) != NULL) {

		fprintf(fp, "# PCYCLE : AMCC NVram Readout from addr $%x to $%x (time stamp = %ld)\n", \
		               ctrl.start, ctrl.stop, time(NULL));

		for (addr = ctrl.start; addr <= ctrl.stop; addr++) {
			if ( (addr != ctrl.start) && ((addr % 16) == 0) )
				fputc('\n', fp);
			fprintf(fp, "%02x ", data[addr]);
			}
			
		fclose(fp);
		return(0);
		}

	else {
		printf("ERROR on opening file `%s'", ctrl.file_sav);
		fflush(stdout);
		perror(" ");
		printf("\n");
		return(-1);
	}
}


/**/
int Write_AMCC_NVram(PCITST_nvr ctrl, u_char *data)
/*+*****************************************************************************
 Purpose     : program the AMCC serial NVram.
 Description : max device = 24C16 (address range : 0x000 -> 0x7FF)
               fill the NVram contents with the array pointed by data.
 Arg(s) In   : a structure ctrl of type PCITST_nvr.
               a pointer on the array data to write the NVram with.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	unsigned short addr;
		
	if (ctrl.start > ctrl.stop || ctrl.stop >= NVRAM_MAX_SIZE) {
		Print_Msg(ERROR, "on NVram addresses selection.", 1);
		return(-1);
		}
		
	for (addr = ctrl.start; addr <= ctrl.stop; addr++) { 

		if (NVRAM_Cycle(WRITE, addr, data[addr]) < 0) {
			Print_Msg(ERROR, "on writing AMCC NVram", 1);
			return(-1); 
			}
		}
	
	return(0);
}


/**/
int Load_File_NVram(PCITST_nvr ctrl, u_char *data)
/*+*****************************************************************************
 Purpose     : Load a file on hard disk to program the serial NVram.
 Description : Load the file contents into the array pointed by data.
               Address range is limited to [$40 .. $7F] (64 bytes)
 Arg(s) In   : a structure ctrl of type PCITST_nvr.
               a pointer on the array data to load.
 Arg(s) Out  : none
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
	FILE *fp;
	char line[80];
	unsigned int num_line = 0, nvr_data[64];
	
	int register i = 0;
				
	if ( (fp = fopen(ctrl.file_src, "r")) != NULL) { 
		
		/* open NVram file with the 16 x 4 bytes to write */
			
		while (fgets(line, sizeof(line), fp) != NULL) { /* read NVram file line by line */

			num_line ++;
			
			if (line[0] != '#') {	/* this line contains significant data (else comments) */

				if (i >= 64) {
					Print_Msg(ERROR, "on reading file NVram contents", -1);
					Print_Msg(INFO,  "\tYou have more than 4 data lines of 16 bytes each.", 1);
					fclose(fp);
					return(-1);
					}
						
				if (sscanf(line,"%x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x", 
				           &nvr_data[i+0], &nvr_data[i+1], &nvr_data[i+2], &nvr_data[i+3],
				           &nvr_data[i+4], &nvr_data[i+5], &nvr_data[i+6], &nvr_data[i+7],
				           &nvr_data[i+8], &nvr_data[i+9], &nvr_data[i+10],&nvr_data[i+11],
				           &nvr_data[i+12],&nvr_data[i+13],&nvr_data[i+14],&nvr_data[i+15]) != 16) {
					Print_Msg(ERROR, "on line format in file NVram.", -1);
					Print_Msg(INFO,  "\tYou must have 16 data bytes per line.", 1);
					printf("\t(cf line %d in file %s)\n", num_line, ctrl.file_src);
					fclose(fp);
					return(-1);
					}		
				i += 16; /* ready for next line of 16 following bytes */
				}
			} /* end of reading NVram file */

		fclose(fp); /* close the NVram file */

		if (i != 64) {
			Print_Msg(ERROR, "on reading file NVram contents", -1);
			Print_Msg(INFO,  "\tYou have less than 4 data lines of 16 bytes each.", 1);
			return(-1);
			}

		if ( (nvr_data[1] != 0x10) || (nvr_data[0] != 0xE8) || 
/*		     (nvr_data[3] != 0x47) || (nvr_data[2] != 0x50) || */
		    ((nvr_data[16] & 0xFC) != 0xC0) || (nvr_data[17] != 0xFF) || 
			 (nvr_data[18] != 0xE8) || (nvr_data[19] != 0x10) ) 
			Print_Msg(WARNING, "the file NVram contains irrelevant bytes to a chip AMCC S593x.", 1);
		
		/* Copy src file contents into array data */
		
		for (i = 0x40; i <= 0x7F; i++) 
			data[i] = nvr_data[i-64];
						
		return(0);  
		} 
	else {
		printf("ERROR ! on opening file `%s'", ctrl.file_src);
		fflush(stdout);
		perror(" ");
		printf("\n");
		return(-1); 
		}
}


/**/
int NVRAM_Cycle(char mode, unsigned short offset, unsigned char data)
/*+*****************************************************************************
 Purpose     : Reading and Writing sequence on serial PCI NVRAM via chip AMCC.
 Description : cf description of AMCC Bus Master Ctrl/Status reg. (MCSR)
 Arg(s) In   : mode   = READ or WRITE
	       offset = byte address to access
               data   = byte to write
 Arg(s) Out  : errno
 Return(s)   : 0 = OK / -1 = NOTOK
*****************************************************************************-*/
{
#define  NVRAM_BUSY  0x80
#if defined NIVISA_PXI
	DWORD usec = 0 ;
#endif	

	u_char ad_low, ad_high, time_out;

	ad_low  = (u_char)  (offset & 0x00FF);
	ad_high = (u_char) ((offset & 0xFF00) >> 8);

	switch(mode) { /* Read or Write Serial NVRam */

	case READ :


		time_out = 40;
		do { /* wait for NVRAM ready (bit 31 of MCSR reg. = 0) */
			time_out --;
#if !defined NIVISA_PXI
			usleep(50);
#endif

#if defined NIVISA_PXI
			usec = 50000 ;
			SleepWrapper(usec) ;
#endif


			Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, &nvd);
		} while (time_out && (nvd & NVRAM_BUSY));
		if (time_out == 0)
			return(-1);
			
		/* set D31 to enable the decode bits D30 & D29 of MCSR reg. */
		/* and to open door for low address latch */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0x80);
									    
		/* load low byte of the address desired */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, ad_low);

		/* latch low address and open door for high address latch */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0xA0);

		/* load high byte of the address desired */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, ad_high);

		/* latch high address and begin the read NVRAM data operation */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0xE0);


		time_out = 40;
		do { /* wait for NVRAM not busy (bit 31 of MCSR reg. = 0) */
			time_out --;
#if !defined NIVISA_PXI
			usleep(50);
#endif

#if defined NIVISA_PXI
			usec = 50000 ;
			SleepWrapper(usec) ;
#endif

			Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, &nvd);
		} while (time_out && (nvd & NVRAM_BUSY));
		if (time_out == 0)
			return(-1);

		/* read the NVRAM data */
		Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, &nvd);

		return(0);

		break;

	case WRITE :
		time_out = 40;
		do { /* wait for NVRAM ready (bit 31 of MCSR reg. = 0) */
			time_out --;
#if !defined NIVISA_PXI
			usleep(50);
#endif

#if defined NIVISA_PXI
			usec = 50000 ;
			SleepWrapper(usec) ;
#endif

		
			Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, &nvd);
		} while (time_out && (nvd & NVRAM_BUSY));
		if (time_out == 0)
			return(-1);		

		/* set D31 to enable the decode bits D30 & D29 of MCSR reg. */
		/* and to open door for the low address latch */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0x80);

		/* load low byte of the address desired */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, ad_low);

		/* latch low address and open door for high address latch */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0xA0);

		/* load high byte of the address desired */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, ad_high);

		/* latch high address and disable the decode bits D30 & D29 */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0x00);

		/* load data byte to be written */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, data);

		/* latch data byte and begin the write NVRAM data operation */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0xC0);

		time_out = 40;
		do { /* wait for NVRAM not busy (bit 31 of MCSR reg. = 0) */
			time_out --;
#if !defined NIVISA_PXI
			usleep(50); /* Self-Timed write cycle = 10 ms max. */
#endif

#if defined NIVISA_PXI
			usec = 50000 ;
			SleepWrapper(usec) ;
#endif
		
			Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, &nvd);
		} while (time_out && (nvd & NVRAM_BUSY));

		return(0); /* Problem with checking read-back data */

		/******** following part to be debugged ********/
		
		/* read back the address latched */
		Write_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, 0xE0);

		do { /* wait for NVRAM not busy (bit 31 of MCSR reg. = 0) */
			Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVCMD, PCIDRV_8BITS, &nvd);
		} while (nvd & NVRAM_BUSY);

		/* read the NVRAM data */
		Read_PCI(BADR0, AMCC_OP_REG_MCSR_NVDATA, PCIDRV_8BITS, &nvd);

		if ((u_char)nvd != data) {
			Print_Msg(ERROR, "on read-back NVram value", 1);
			printf("Written %02x - Read %02x\n", data,(u_char)nvd);
			fflush(stdout);
			return (-1);
			}
		else
			return(0);
		break;

	default :
		break;

	}

	return(-1);
}
