
/*+*****************************************************************************

 File       : FCT_HEXA.C      
 Project    : Test program environment for PCI..
 Description: Hexadecimal, Binary & Decimal conversions.
 Author(s)  : Ch. Herve

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/


unsigned long pow2(int);


/**/
char *binw(int decival, int n)
/*+*****************************************************************************
 Purpose    : returns a string containing the 'n' first bits of an integer.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  :
*****************************************************************************-*/
{
	int i, j, k, l;
	static char line[100];
	char invline[100];		
	unsigned full, fulli, half;
		
	full = decival;
	i = j = 0, k = half = 1;

	while (k <= n) {                     
		half = full/2;
		fulli = full - (2 * half);
		if (j == 4) {
			invline[i] = ' ';
			++i;
			j = 0;
			}
		if (fulli) 
			invline[i] = '1';
		else
			invline[i] = '0';
		++i, ++j, ++k;
		full = half;
		}

	for (l = 0; l <= (i-1); ++l) 
		line[l] = invline[i-1-l];
	line[i] = '\0';

	return(line);
}


/**/
char *bin32(int decival)
/*+*****************************************************************************
 Purpose    : returns a string containing the 32 bits of an integer.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  :
*****************************************************************************-*/
{
	return(binw(decival,32));
}


/**/
char *bin16(int decival)
/*+*****************************************************************************
 Purpose    : returns a string containing the 16 bits of an integer.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  :
*****************************************************************************-*/
{
	return(binw(decival,16));
}


/**/
char *bin8(int decival)
/*+*****************************************************************************
 Purpose    : returns a string containing the 8 bits of an integer.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  :
*****************************************************************************-*/
{
	return(binw(decival,8));
}


/**/
long gray_to_bin(long nb)
/*+*****************************************************************************
 Purpose    : converts a gray code into its binary value.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  :
*****************************************************************************-*/
{
	register int i;

	for (i = 25; i > -1; i--)
		if ( nb & pow2(i+1))
			nb ^= pow2(i);
	return(nb);
}


/**/
unsigned long pow2(int num)
/*+*****************************************************************************
 Purpose    : raise num to the power of 2.
 Description: 
 Arg(s) In  : 
 Arg(s) Out : 
 Return(s)  : 
*****************************************************************************-*/
{
	unsigned long result = 1;

	if ( (num >= 0) && (num <= 31) ) {
		while (num) {
			result *= 2;
			num --;
			}
		return(result);
		}
	else return(0);
}
