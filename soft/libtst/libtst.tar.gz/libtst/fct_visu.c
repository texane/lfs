

/*+*****************************************************************************

 File       : FCT_VISU.C      
 Project    : Test program environment for PCI
 Description: Misc. functions to deal with screen & keyboard in a friendly way.
 Author(s)  : Ph. Chappelet

 Copyright (c) 1999 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/

/*
 Include the header files
 */
#if ( defined(WIN32) || defined(_WIN32) || \
	defined(__WIN32__) || defined(__NT__) )
#define NIVISA_PXI
#endif

#if !defined NIVISA_PXI
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <termios.h>

/*
 Include Specific Header files
 */

#if 0 /* was */
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "../../../defs/pci_env_tst.h"
#else /* is */
#include "pcidrvgen.h"
#include "defs/pci_env_tst.h"
#endif

#endif /** not NIVISA_PXI **/

#if defined NIVISA_PXI
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>
#include "wdc_defs.h"
#include "utils.h"
#include "status_strings.h"
#include "C:\WinDriver\samples\shared\pci_regs.h"
#include "pcidrvgen.h"
#include "amcc.h"
#include "pci_env_tst.h"

//extern ViSession defaultRM ;
//extern ViSession visa_instr ;
extern DWORD EsrfManufId ;
extern CodeName EsrfModelsCodes[] ;
extern Keyboard_Input ;
#endif /** NIVISA_PXI **/

/**/
void Signal_Handler(int signo)
/*+*****************************************************************************
 Purpose     : signal handling function for this process.
 Description : signal_handler() specifies the  action on receipt of signo.
 Arg(s) In   : signo = signal number (except SIGKILL & SIGSTOP).
 Arg(s) Out  : Keyboard_Input (set to TRUE).
 Return(s)   : none
*****************************************************************************-*/
{
	if (signo == SIGINT)
		Keyboard_Input = TRUE;
}  


/**/
void Wait_and_See(char *message)
/*+*****************************************************************************
 Purpose     : display a message and wait for a key depressed
 Description :
 Arg(s) In   : message to display
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
#if defined NIVISA_PXI

	int c = '\0';
	printf("\n\t\t\t   %s", message); fflush(stdout);
 	do { c = getchar(); } while ((void *)c == NULL);
       
#endif
#if !defined NIVISA_PXI
	char *ibuf = NULL;
	struct termios org_tio, cur_tio;

	/* Display foot message */
	/* Move_Cursor(24, 40-(strlen(message)/2)); */
	printf("\n\t\t\t   %s", message);
	fflush(stdout);

	/* Get current terminal settings */
	tcgetattr(STDIN_FILENO, &cur_tio);

	/* Save current terminal settings */
	org_tio = cur_tio;

	/* Set new port settings for canonical input processing */
	cur_tio.c_lflag &= ~ICANON; /* raw mode */
	cur_tio.c_lflag &= ~ECHO;   /* no echo  */

	cur_tio.c_cc[VMIN]  = 1; /* Read one char only */
	cur_tio.c_cc[VTIME] = 0; /* NO Time-Out */
	tcsetattr(STDIN_FILENO, TCSANOW, &cur_tio);

	/* Wait for character input */
	read(STDIN_FILENO, ibuf, 1);
	tcflush(STDIN_FILENO, TCIOFLUSH);

	/* Restore original terminal settings */
	tcsetattr(STDIN_FILENO, TCSANOW, &org_tio);
#endif
}

/**/
void Clear_Screen(void)
/*+*****************************************************************************
 Purpose     : Clear the screen (code clear/cl).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c%c%c", 0x1B, '[', 'H', 0x1B, '[', 'J');
	fflush(stdout);
#if !defined NIVISA_PXI
	usleep(50000);
#endif
}


/**/
void Set_Bold(void)
/*+*****************************************************************************
 Purpose     : Turn Bold characters ON (code bold/md)
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c", 0x1B, '[', '1', 'm');
	fflush(stdout);
}


/**/
void Set_Blink(void)
/*+*****************************************************************************
 Purpose     : Turn Blinking ON (code blink/mb).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c",     0x1B, '[', '5', 'm');
	fflush(stdout);
}


/**/
void Set_Reverse(void)
/*+*****************************************************************************
 Purpose     : Set Reverse video ON (code rev/mr).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c",     0x1B, '[', '7', 'm');
	fflush(stdout);
}


/**/
void Set_Underline(void)
/*+*****************************************************************************
 Purpose     : Turn Underlined characters ON (code smul/us).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c",     0x1B, '[', '4', 'm');
	fflush(stdout);
}


/**/
void Clr_Underline(void)
/*+*****************************************************************************
 Purpose     : Turn Underlined characters OFF (rmul/ue).
 Description : WARNING : Compatible mode DTTERM, LINUX
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c%c",   0x1B, '[', '2', '4', 'm');
	fflush(stdout);
}


void Clr_Attr(void)
/*+*****************************************************************************
 Purpose     : Turn all attributes OFF (code sgr0/me).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c%c%c%c", 0x1B, '[', '0', 'm');	/* turn off all attributes */
	fflush(stdout); 	
}


/**/
void Ring_Bell(void)
/*+*****************************************************************************
 Purpose     : Beeps the terminal (code bel).
 Description : Compatible mode DTTERM, LINUX & VT100.
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
	printf("%c", 0x07);	/* <Ctrl-G> */
	fflush(stdout); 	
}


/**/
void Print_Msg(u_char code, char *msg, u_int tempo)
/*+*****************************************************************************
 Purpose     : print a message with a priority flag & wait for a while.
 Description : tempo cannot be greater than 10 sec.
 Arg(s) In   : code  = INFO/WARNING/ERROR (type of message)
               msg   = message to display on screen
               tempo = time to display the message (in sec.)
 Arg(s) Out  : none
 Return(s)   : nothing
*****************************************************************************-*/
{
#if defined NIVISA_PXI
	DWORD usec = 0 ;
#endif	

	switch(code) {

		default :
		case INFO : 
			printf("%s\n", msg);           
			break;

		case WARNING :
			printf("WARNING %s\n", msg); 
			break;

		case ERROR :
			Set_Bold();
			printf("\nERROR"); fflush(stdout);
			Clr_Attr();
			printf(" ! %s\n", msg);   
			break;
		}

	if ((int)tempo >= 0) {	
		if (!tempo)
			Wait_and_See("strike <ENTER> to continue"); 
		else
		if (tempo > 10){
#if !defined NIVISA_PXI
			sleep(10);
#endif
#if defined NIVISA_PXI
			usec = 10000 ;
			SleepWrapper(usec) ;
#endif
		}	
		else {
#if !defined NIVISA_PXI
			sleep(tempo);
#endif
#if defined NIVISA_PXI
			SleepWrapper((DWORD)(tempo/1000)) ;
#endif
		}
	}
}
