/*+*****************************************************************************

 File       : flash.c
 Project    : DAnCE COM-Express project
 Description: Uses the generic driver PCIDRVGEN
 Author(s)  : 

 Copyright (c) 2011 by European Synchrotron Radiation Facility,
                       Grenoble, France

*****************************************************************************-*/
#include "flash.h"

#include "../MAP/set_dat.c"
#include "../CFCN/ebn_rst.c"
#include "../CFCN/rst_rst.c"
#include "../CFCN/get_ids.c"
#include "../CFCN/get_sts.c"
#include "../CFCN/get_byt.c"
#include "../CFCN/set_map.c"
#include "../CFCN/set_prm.c"
#include "../CFCN/set_led.c"
#include "../CFCN/set_wen.c"
#include "../CFCN/set_bcl.c"
#include "../CFCN/prg_xil.c"

struct option longopts[4] = {
	{"help",        no_argument, NULL, 'h'},  /* Display Help message */
	{"debug", required_argument, NULL, 'd'},  /* Define debug level */
	{"badr",  required_argument, NULL, '#'},  /* Select a Base Adrs reg. */
	{ 0, 0, 0, 0 } /* last element of the array */	
};

#define MAX_FNAME_LEN 256


/************************************************************************
	Any C-program where want to intercept signal from the keyboard
	then ask user if continue loop (can be for/while etc) or end it.
*************************************************************************/
struct				sigaction kbd;

/***********************************************************************
 Description : signal_handler() specifies the action on receipt of signo
 Arg(s) In   : signo = signal number
 Arg(s) Out  : none
 Return(s)   : none
************************************************************************/

int main(int argc, char *argv[])
/*+*****************************************************************************
 Purpose    : Main section of User's program
 Description:
 Argv[1]    :
 Arg(s) Out : None
 Return(s)  :
*****************************************************************************-*/
{
	int		loop, pc_system;
	unsigned int	did = 0xFFFF;
        FILE		*fp;
	char		bit_file[MAX_FNAME_LEN];
	char		*board_type = NULL;

	opt_dbg = DBG_NONE;
	chip_AMCC = FALSE;

	TEST_OPEN((u_short)did);

	// Check optional argins
	if(argc == 1) {
		printf("Trying to guess module type\n");
	} else if(argc == 3) {
		printf("Using module type: %s\n",argv[1]);
		board_type = argv[1];
	} else {
		printf("\nERROR wrong argins\n");
		printf("Usage: %s [module_type bit_file]\n", argv[0]);
		printf("\tmodule_type: \"DCORE\" \"DUB\" \"KC705\"\n");
		printf("\tbit_file   : BIT file with its path\n");
		TEST_CLOSE();
		exit(-1);
	}

	ebn_rst();
	set_map();
	pc_system = set_prm(board_type);
	if (!strcasecmp(module_target, "unknown")) {
		printf("\nERROR unknown module type\n\n");
		TEST_CLOSE();
		exit(-1);
	}


	// Get the BIT file name
	if (argc == 3) 
		strncpy(bit_file,argv[2],MAX_FNAME_LEN);
	else if (strncmp(module_target, "DCORE", 5) == 0)
		strncpy(bit_file,"BIT/dcore_top.bit",MAX_FNAME_LEN);
	else if (strncmp(module_target, "DUB", 3) == 0)
		strncpy(bit_file,"BIT/dub_top.bit",MAX_FNAME_LEN);
	else if (strncmp(module_target, "KC705", 5) == 0)
		strncpy(bit_file,"BIT/kc705_top.bit",MAX_FNAME_LEN);
	else {
		printf("\nERROR unknown module type\n\n");
		TEST_CLOSE();
		exit(-1);
	}
        

	// Check that the BIT file exists BEFORE erasing flash memory
        fp = fopen(bit_file, "rb");
        if (fp == NULL) {
                printf("\n\tERROR on opening BIT file: %s\n\n",bit_file);
		TEST_CLOSE();
		exit(-1);
        }
	fclose(fp);



	printf(" Downloading Xilinx Flash\n");
	set_led(2);

	printf("\n Erasing Device\n");

	set_wen();
	set_bcl();

	loop = 0;

	while ((get_sts() & 0x00000001) == 0x00000001) {
		if (pc_system == 0) {
			if ((loop % 5000) == 0) {
				printf(".");
				fflush(stdout);
			}
		}
		else {
			if ((loop % 80000) == 0) {
				printf(".");
				fflush(stdout);
			}
		}
		loop += 1;
	}

	printf(" Done\n\n");
	printf(" Programming Flash %s on %s Module\n", 
		flash_pntr.flash_mem_typ, module_target);

	Load_Xilinx(bit_file);

	printf("\n Boot process ...\n");
	rst_rst();
	set_led(0);
	TEST_CLOSE();
	exit(0);
}
