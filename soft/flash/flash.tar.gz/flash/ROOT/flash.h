/*+************************************************************************************

 File:        flash.c
 -----
 Project:     Dcore/DUB PCI-Express devices, uses the driver generic PCIDRVGEN
 --------
 Description: The "flash" program's goal is to rewrite the boot flash memory with a new
 ------------ bitstream's FPGA application and to reboot the whole system. The program
							requires the harware implementation of the "ebs_fspi" Ebone module within
							the FPGA. Hardware implementation is common regardless of the Xilinx FPGA
							and flash memory targets used. Software implementation is common regardless
							of the Xilinx FPGA but must take into account the flash memory ID since the
              bitstream header, if used, must be stored in a specific memory location.
 Author:      Thierry Le Caer
 -------

************************************************************************************-*/

/*************************************************************************************
 PROCESS FLOW
 ------------

 1/  E-bone reset (ebn_rst()).
 2/  Variables setting (set_map()).
 3/  Flash memory manufacturer and device identification read (set_prm()).
 4/  Switch on the green led (set_led(1)).
 5/  Entire memory erase instruction (set_wen() + set_bcl() + get_sts()).
 6/  Reading of a bitstream file content from BIT/dcore.bit or BIT/dub.bit.
 7/  Flash memory writing process. N x Page Program instructions according
     to the xxx.bit bitstream file size.
		 The page program instruction allows up to 256 bytes to be written in a single
		 sequence. Status reads are required between each instruction to check that the
		 write is complete and performed and that the clock edges count corresponding to
		 the sequence is correct.
 8/  Header writing process.
 9/  Header reading process.
 10/ Full system boot process consisting of the transfer of the flash content
     into the FPGA, followed by the Comm-express reset (rst_rst()).

**************************************************************************************/

/* Include General Header files */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <termios.h>
#include <sys/stat.h>

/* Include Specific Header files */
#include "/segfs/linux/drv/pci/V1.6/amcc.h"
#include "/segfs/linux/drv/pci/V1.6/pcidrvgen.h"
#include "/segfs/linux/csel/util/libtst/V1.4/pci_env_tst.h"

#define true							1
#define false							0
#define	page_size					256
#define STRLEN						40

/******************** BADR0 memory and registers area ******************/
/***********************************************************************/
#define	CTRL_REG					0x0000
#define	PROB_REG					0x0004
#define	CFGR_REG					0x00C0
#define EBS_FSPI					0x0000


/* Declaration of Library functions (A CONSERVER) */

extern int TEST_OPEN(u_short), TEST_CLOSE(void);

extern int Read_PCI_Config(PCIDRV_hdr *), Write_PCI_Config(PCIDRV_arg *);
extern void Set_PCI_Config(PCIDRV_arg *), Display_PCI_Header(PCIDRV_hdr, int);
extern int Dev_Info(unsigned short, unsigned short);

extern int Read_PCI(u_int, u_int, u_int, u_int *);
extern int Write_PCI(u_int, u_int, u_int, u_int);
extern int Bus_Master(u_int, u_int, u_int, u_int *);

extern int Rd_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);
extern int Wr_Burst_PCI(u_int, u_int, u_int, u_int, u_int *);

extern int Read_AMCC_NVram(PCITST_nvr, unsigned char *);
extern int Store_File_NVram(PCITST_nvr, unsigned char *);
extern int Write_AMCC_NVram(PCITST_nvr, unsigned char *);
extern int Load_File_NVram(PCITST_nvr, unsigned char *);
extern int Display_AMCC_NVram(PCITST_nvr, unsigned char *);

extern int Load_Virtex(char *);

extern void Wait_and_See(char *);
extern void Print_Msg(char, char *, int);
extern void Clear_Screen(void), Set_Bold(void), Clr_Attr(void), Ring_Bell(void);

PCIDRV_hdr header;
PCIDRV_arg argusr;
