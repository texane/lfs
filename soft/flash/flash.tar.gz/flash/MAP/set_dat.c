/***********************************************************************
 Purpose     : global variables definitions of flash program.
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
************************************************************************/
extern char		*bin32(int), *bin16(int), *bin8(int);

char					Line[STRLEN], pathname[STRLEN], module_target[STRLEN];
int						Ret, header_size;
unsigned int	Offs, Data, Code_ID, Config[32];

/*************** Flash memory structure declaration area ***************/
/***********************************************************************/
struct flash_info {
	char					flash_mem_typ[STRLEN];
	unsigned int	manufacturer_id;
	unsigned int	device_id;
	unsigned int	last_sect_addr;
	unsigned int	status_register;
	unsigned int	ebs_fspi_stat[4];
};
struct flash_info flash_pntr;
