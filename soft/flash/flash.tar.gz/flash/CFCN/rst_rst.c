/**********************************************************************
 Purpose     : Software reset
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void rst_rst()
{
	Ret = Write_PCI(BADR0, (CTRL_REG + 8), PCIDRV_32BITS, Code_ID);
}
