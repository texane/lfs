/**********************************************************************
 Purpose     : E-Bone reset
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void ebn_rst()
{
	Ret = Read_PCI(BADR0, PROB_REG, PCIDRV_32BITS, &Data);
	usleep(100);

	Ret = Read_PCI(BADR0, PROB_REG, PCIDRV_32BITS, &Data);
	Data &= 0x3fffffff;
	Data |= 0x40000000;
	Ret = Write_PCI(BADR0, PROB_REG, PCIDRV_32BITS, Data);
	Data &= 0x3fffffff;
	Ret = Write_PCI(BADR0, PROB_REG, PCIDRV_32BITS, Data);
	usleep(100);
}
