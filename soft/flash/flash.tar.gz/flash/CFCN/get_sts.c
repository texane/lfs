/**********************************************************************
 Purpose     : Flash memory status register 1 read
 Description :
 Arg(s) In   : none
 Arg(s) Out  : Status register number
 Return(s)   : status
***********************************************************************/

unsigned int get_sts()
{
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x004), PCIDRV_32BITS, 0x00000001);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x008), PCIDRV_32BITS, 0x00000010);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x000), PCIDRV_32BITS, 0x05000000);
	Ret = Read_PCI(BADR1, (EBS_FSPI + 0x018), PCIDRV_32BITS, &flash_pntr.ebs_fspi_stat[2]);
	return(flash_pntr.ebs_fspi_stat[2] & 0x000000FF);
}
