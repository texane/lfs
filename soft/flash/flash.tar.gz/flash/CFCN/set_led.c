/**********************************************************************
 Purpose     : Status led write process
 Description :
 Arg(s) In   : Leds value
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void set_led(int led_state)
{
	Ret = Read_PCI(BADR0, CTRL_REG, PCIDRV_32BITS, &Data);
	Data &= 0xffffcfff;
	led_state <<= 12;
  Data |= led_state;
	Ret = Write_PCI(BADR0, CTRL_REG, PCIDRV_32BITS, Data);
}
