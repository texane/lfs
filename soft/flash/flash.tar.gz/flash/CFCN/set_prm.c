/**********************************************************************
 Purpose     : Parameters setting
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/
#define TYPE_UNKNOWN 1
#define TYPE_DCORE   2
#define TYPE_DUB     3
#define TYPE_KC705   4
int set_prm(char *board_type)
{
	int i;
	int module_type = TYPE_UNKNOWN;


	Ret = Write_PCI(BADR0, (CTRL_REG + 0xC), PCIDRV_32BITS, 0x80000000);
	usleep(10);
	for(i = 0;i < 32;i++) Ret = Read_PCI(BADR0, (CFGR_REG + (4 * i)), PCIDRV_32BITS, &Config[i]);
	Ret = Write_PCI(BADR0, (CTRL_REG + 0xC), PCIDRV_32BITS, 0x00000000);


	// Check if autodetection is requested
	if(board_type == NULL) {
		get_ids();
		if ((flash_pntr.manufacturer_id == 0x01) && 
			(flash_pntr.device_id == 0x0216)) 
			module_type = TYPE_DCORE;

		if ((flash_pntr.manufacturer_id == 0x20) && 
			(flash_pntr.device_id == 0x2018)) 
			module_type = TYPE_DUB;

		if ((flash_pntr.manufacturer_id == 0x20) && 
			(flash_pntr.device_id == 0xBA18)) 
			module_type = TYPE_KC705;
	} else {
		if(!strcasecmp(board_type,"DCORE")) 
			module_type = TYPE_DCORE;

		if(!strcasecmp(board_type,"DUB"))   	
			module_type = TYPE_DUB;

		if(!strcasecmp(board_type,"KC705")) 
			module_type = TYPE_KC705;
	}




	if( module_type == TYPE_DCORE) {
		strcpy(module_target, "DCORE");
		strcpy(flash_pntr.flash_mem_typ, "Spansion S25FL064P");
		flash_pntr.last_sect_addr = 0x007f0000;
		Code_ID = Config[1];
		i = 0;
	}
	else if( module_type == TYPE_DUB) {
		strcpy(module_target, "DUB");
		strcpy(flash_pntr.flash_mem_typ, "Numonyx M25P128");
		flash_pntr.last_sect_addr = 0x00fc0000;
		Code_ID = Config[0];
		i = 0;
	}
	else if( module_type == TYPE_KC705) {
		strcpy(module_target, "KC705");
		strcpy(flash_pntr.flash_mem_typ, "Numonyx N25Q128");
		flash_pntr.last_sect_addr = 0x00fc0000;
		Code_ID = Config[0];
		i = 1;
	}
	else {
		strcpy(module_target, "Unknown");
		strcpy(flash_pntr.flash_mem_typ, "Unknown");
		Code_ID = 0;
		i = 0;
	}

	return(i);
}
