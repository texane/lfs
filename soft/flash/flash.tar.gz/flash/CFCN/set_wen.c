/**********************************************************************
 Purpose     : Write Memory Enable instruction
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void set_wen()
{
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x004), PCIDRV_32BITS, 0x00000001);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x008), PCIDRV_32BITS, 0x00000008);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x000), PCIDRV_32BITS, 0x06000000);
}
