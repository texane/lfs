/**********************************************************************
 Purpose     : Flash memory read data byte
 Description :
 Arg(s) In   : none
 Arg(s) Out  : Status register number
 Return(s)   : status
***********************************************************************/

unsigned int get_byt()
{
	Offs &= 0x00FFFFFF;
	Offs |= 0x0B000000;

	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x004), PCIDRV_32BITS, 0x00000001);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x008), PCIDRV_32BITS, 0x00000040);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x000), PCIDRV_32BITS, Offs);

	Ret = Read_PCI(BADR1, (EBS_FSPI + 0x018), PCIDRV_32BITS, &flash_pntr.ebs_fspi_stat[2]);
	return(flash_pntr.ebs_fspi_stat[2] & 0x00FFFFFF);
}
