/**********************************************************************
 Purpose     : variables initialization of comex program.
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void set_map(void)
{
	int i;

  for(i = 0;i < 32;i++) Config[i] = 0;

	flash_pntr.manufacturer_id = 0;
	flash_pntr.device_id = 0;
	flash_pntr.last_sect_addr = 0;
	flash_pntr.status_register = 0;
	for(i = 0;i < 4;i++) flash_pntr.ebs_fspi_stat[i] = 0;

	Ret = 0;
	Offs = 0;
	Data = 0;
	Code_ID = 0;
	header_size = 88;

	strcpy(flash_pntr.flash_mem_typ, "");
	strcpy(module_target, "");
	strcpy(pathname, "");
}
