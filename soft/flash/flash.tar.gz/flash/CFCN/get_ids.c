/**********************************************************************
 Purpose     : Flash memory read Manufacturer and Device IDs
 Description :
 Arg(s) In   : none
 Arg(s) Out  : none
 Return(s)   : nothing
***********************************************************************/

void get_ids()
{
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x004), PCIDRV_32BITS, 0x00000001);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x008), PCIDRV_32BITS, 0x00000020);
	Ret = Write_PCI(BADR1, (EBS_FSPI + 0x000), PCIDRV_32BITS, 0x9F000000);
	Ret = Read_PCI(BADR1, (EBS_FSPI + 0x018), PCIDRV_32BITS, &flash_pntr.ebs_fspi_stat[2]);

	flash_pntr.manufacturer_id = flash_pntr.ebs_fspi_stat[2];
	flash_pntr.manufacturer_id >>= 16;
	flash_pntr.manufacturer_id &= 0x000000ff;
	flash_pntr.device_id = (flash_pntr.ebs_fspi_stat[2] & 0x0000ffff);
}
